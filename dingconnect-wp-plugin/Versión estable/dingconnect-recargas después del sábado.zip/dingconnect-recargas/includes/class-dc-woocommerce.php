<?php
if (!defined('ABSPATH')) {
    exit;
}

if (class_exists('DC_Recargas_WooCommerce')) {
    return;
}

/**
 * WooCommerce integration for DingConnect Recargas.
 *
 * Handles: virtual product management, cart customization, checkout enforcement,
 * phone-based login, and order processing (real DingConnect transfer on payment).
 *
 * IMPORTANT: For real transfers to execute after payment, the admin must enable
 * "allow_real_recharge" in plugin settings (DingConnect Recargas > Ajustes).
 * Without it, all transfers will be validate-only regardless of WooCommerce flow.
 */
class DC_Recargas_WooCommerce {

    /** @var DC_Recargas_API */
    private $api;

    public $voucher_service;
    public $voucher_outbox;
    public $voucher_renderer;

    public function __construct($api) {
        $this->api = $api;
        $this->voucher_service = new DC_Recargas_Voucher();
        $this->voucher_outbox = new DC_Recargas_Voucher_Outbox($this->api);
        $this->voucher_renderer = new DC_Recargas_Voucher_Renderer();
        $this->api->set_woocommerce($this);

        // Add-to-cart is handled by DC_Recargas_REST, which delegates here via filter

        // Compatibility mitigation: initialize PHP session early on checkout requests
        // when third-party gateways (e.g., Tropipay) start sessions too late.
        add_action('init', [$this, 'stabilize_checkout_php_session_compat'], 0);

        // Initialize WC cart/session early for REST requests (must be on woocommerce_init, not inside the callback)
        add_action('woocommerce_init', [$this, 'maybe_load_cart_for_rest']);

        // Add-to-cart filter (delegated from REST class)
        add_filter('dc_recargas_add_to_cart', [$this, 'handle_add_to_cart'], 10, 2);

        // Cart customization
        add_action('woocommerce_before_calculate_totals', [$this, 'set_custom_price'], 20, 1);
        add_filter('woocommerce_get_item_data', [$this, 'display_cart_item_data'], 10, 2);
        add_filter('woocommerce_cart_item_name', [$this, 'custom_cart_item_name'], 10, 3);
        add_filter('woocommerce_order_item_name', [$this, 'filter_order_item_name_branding'], 10, 3);
        add_filter('woocommerce_cart_item_thumbnail', [$this, 'suppress_recarga_cart_item_thumbnail'], 10, 3);
        add_filter('woocommerce_is_purchasable', [$this, 'force_recarga_product_purchasable'], 10, 2);
        add_filter('woocommerce_cart_item_is_purchasable', [$this, 'force_recarga_cart_item_purchasable'], 10, 3);
        add_filter('woocommerce_cart_item_is_in_stock', [$this, 'force_recarga_cart_item_in_stock'], 10, 3);
        add_filter('woocommerce_add_error', [$this, 'suppress_generic_cart_issue_error_for_dc_only'], 10, 1);
        add_filter('woocommerce_get_cart_item_from_session', [$this, 'restore_recarga_cart_item_from_session'], 20, 3);
        add_action('woocommerce_cart_loaded_from_session', [$this, 'normalize_dc_cart_after_session_load'], 20);
        add_action('woocommerce_check_cart_items', [$this, 'diagnose_dc_cart_item_issues'], 1);
        add_action('woocommerce_check_cart_items', [$this, 'cleanup_dc_only_generic_cart_notice_late'], 999);
        add_action('woocommerce_before_checkout_form', [$this, 'cleanup_dc_only_generic_cart_notice_late'], 1);
        add_action('woocommerce_checkout_process', [$this, 'cleanup_dc_only_generic_cart_notice_late'], 1);

        // Order meta
        add_action('woocommerce_checkout_create_order_line_item', [$this, 'save_order_item_meta'], 10, 4);

        // Cart restoration fallback (silent and explicit)
        add_action('template_redirect', [$this, 'handle_cart_restoration_fallback'], 4);

        // Redirect DC-only cart directly to checkout (skip cart page)
        add_action('template_redirect', [$this, 'redirect_dc_only_cart_to_checkout'], 5);

        // Explicit cancel button for isolated recharges
        add_action('woocommerce_checkout_before_customer_details', [$this, 'render_cancel_recharge_button']);

        // Mandatory registration (only when cart is mixed DC + regular products)
        add_filter('woocommerce_checkout_registration_required', [$this, 'force_registration']);
        add_filter('pre_option_woocommerce_enable_guest_checkout', [$this, 'disable_guest_checkout']);

        // Checkout fields + address validation bypass for DC-only
        add_filter('woocommerce_checkout_fields', [$this, 'customize_checkout_fields']);
        add_filter('woocommerce_new_customer_data', [$this, 'prefill_customer_phone']);
        add_action('woocommerce_after_checkout_validation', [$this, 'clear_address_validation_errors_for_dc'], 10, 2);

        // Phone login
        add_filter('authenticate', [$this, 'authenticate_by_phone'], 30, 3);

        // Order processing - fire DingConnect transfer on payment
        // Three hooks to cover all gateway patterns:
        // - payment_complete: Stripe, PayPal IPN and other gateways that call $order->payment_complete() directly
        // - status_processing: gateways that transition to "processing" after payment
        // - status_completed: gateways that go directly to "completed" (e.g., free/manual orders)
        add_action('woocommerce_payment_complete', [$this, 'handle_payment_complete']);
        add_action('woocommerce_order_status_processing', [$this, 'handle_order_status_processing']);
        add_action('woocommerce_order_status_completed', [$this, 'handle_order_status_completed']);
        add_action('woocommerce_order_status_failed', [$this, 'handle_order_terminal_failure']);
        add_action('woocommerce_order_status_cancelled', [$this, 'handle_order_terminal_failure']);
        add_action('woocommerce_order_status_refunded', [$this, 'handle_order_terminal_failure']);
        add_action('dc_recargas_retry_transfer', [$this, 'process_retry_transfer'], 10, 2);

        // Restrict checkout payment gateways for recarga carts
        add_filter('woocommerce_payment_gateways', [$this, 'filter_gateway_classes_for_dc_checkout'], 1);
        add_filter('woocommerce_available_payment_gateways', [$this, 'filter_available_payment_gateways'], 20);

        // Optional UI guard: hide Advanced Coupons store credit block in DC-only checkout
        add_action('wp_footer', [$this, 'maybe_hide_acfw_store_credit_ui'], 99);

        // Manual reconciliation + voucher rendering
        add_filter('woocommerce_order_actions', [$this, 'register_manual_reconcile_action']);
        add_action('woocommerce_order_action_dc_recargas_manual_reconcile', [$this, 'handle_manual_reconcile_action']);
        add_action('woocommerce_order_action_dc_resend_voucher', [$this, 'handle_resend_voucher_action']);
        add_action('woocommerce_thankyou', [$this, 'render_thankyou_voucher_summary'], 25);
        add_filter('woocommerce_email_order_meta_fields', [$this, 'inject_voucher_meta_into_email'], 10, 3);

        add_filter('woocommerce_customer_order_actions', [$this, 'filter_customer_order_actions'], 10, 2);
        add_filter('woocommerce_my_account_my_orders_actions', [$this, 'filter_my_account_orders_actions'], 10, 2);

        // Admin order display
        add_action('woocommerce_after_order_itemmeta', [$this, 'display_order_item_recarga_meta'], 10, 3);
    }

    /* ---------------------------------------------------------------
     * 1. Base Product Management
     * ------------------------------------------------------------- */

    private function get_or_create_base_product() {
        $base_product_name = 'Recarga Internacional Cubakilos';
        $product_id = (int) get_option('dc_recargas_wc_product_id', 0);

        if ($product_id && get_post_status($product_id) === 'publish') {
            $existing = wc_get_product($product_id);
            if ($existing instanceof WC_Product_Simple) {
                $current_name = (string) $existing->get_name();
                if ($current_name === '' || stripos($current_name, 'DingConnect') !== false) {
                    $existing->set_name($base_product_name);
                }
                // Keep base recarga product always purchasable for checkout/cart validation.
                $existing->set_catalog_visibility('hidden');
                $existing->set_virtual(true);
                $existing->set_sold_individually(false);
                $existing->set_regular_price('0');
                call_user_func([$existing, 'save']);
            }

            // Stock flags via meta to stay compatible with local WP stubs.
            update_post_meta($product_id, '_manage_stock', 'no');
            update_post_meta($product_id, '_stock_status', 'instock');
            update_post_meta($product_id, '_backorders', 'no');
            delete_post_meta($product_id, '_thumbnail_id');
            delete_post_meta($product_id, '_product_image_gallery');

            return $product_id;
        }

        $product = new WC_Product_Simple();
        $product->set_name($base_product_name);
        $product->set_status('publish');
        $product->set_catalog_visibility('hidden');
        $product->set_regular_price('0');
        $product->set_virtual(true);
        $product->set_sold_individually(false);
        $product_id = (int) call_user_func([$product, 'save']);

        update_post_meta($product_id, '_manage_stock', 'no');
        update_post_meta($product_id, '_stock_status', 'instock');
        update_post_meta($product_id, '_backorders', 'no');
        delete_post_meta($product_id, '_thumbnail_id');
        delete_post_meta($product_id, '_product_image_gallery');

        update_option('dc_recargas_wc_product_id', $product_id);
        return $product_id;
    }

    public function filter_order_item_name_branding($item_name, $item, $is_visible) {
        $doing_ajax = function_exists('wp_doing_ajax') ? wp_doing_ajax() : (defined('DOING_AJAX') && DOING_AJAX);
        if (is_admin() && !$doing_ajax) {
            return $item_name;
        }

        if (!is_string($item_name) || $item_name === '') {
            return $item_name;
        }

        if (stripos($item_name, 'DingConnect') === false) {
            return $item_name;
        }

        return str_ireplace('DingConnect', 'Cubakilos', $item_name);
    }

    /* ---------------------------------------------------------------
     * 2. WC Session Helper (critical for REST + WC cart)
     * ------------------------------------------------------------- */

    /**
     * Load WC cart/session for REST requests.
     * Must run on woocommerce_init (early), not inside the REST callback.
     */
    public function maybe_load_cart_for_rest() {
        if (!defined('REST_REQUEST') || !REST_REQUEST) return;
        if (function_exists('wc_load_cart')) {
            wc_load_cart();
        }
    }

    /**
     * Defensive session/cart bootstrap for REST add-to-cart.
     * Some hosting/plugin combinations skip cart bootstrap before REST callbacks.
     */
    private function ensure_wc_session() {
        if (!defined('REST_REQUEST') || !REST_REQUEST) return;

        if (function_exists('wc_load_cart') && (WC()->cart === null || WC()->session === null)) {
            wc_load_cart();
        }

        if (WC()->session === null) {
            WC()->session = new WC_Session_Handler();
            WC()->session->init();
        }

        if (WC()->customer === null) {
            WC()->customer = new WC_Customer(get_current_user_id());
        }

        if (WC()->cart === null) {
            WC()->cart = new WC_Cart();
            WC()->cart->get_cart();
        }
    }


    /* ---------------------------------------------------------------
     * 3. Add-to-Cart Handler (called via dc_recargas_add_to_cart filter)
     * ------------------------------------------------------------- */

    public function handle_add_to_cart($result, $data) {
        $this->ensure_wc_session();

        if (WC()->cart === null) {
            $this->api->log_operational_event('cart_add_failed', [
                'status' => 'error',
                'account_number' => (string) ($data['account_number'] ?? ''),
                'sku_code' => (string) ($data['sku_code'] ?? ''),
                'send_value' => (float) ($data['send_value'] ?? 0),
                'currency' => (string) ($data['send_currency_iso'] ?? ''),
                'raw_response' => ['reason' => 'cart_unavailable'],
            ]);
            return new WP_Error('dc_cart_unavailable', 'No se pudo inicializar el carrito en este entorno.');
        }

        $product_type = sanitize_text_field((string) ($data['product_type'] ?? ''));
        $redemption_mechanism = sanitize_text_field((string) ($data['redemption_mechanism'] ?? ''));
        $lookup_bills_required = !empty($data['lookup_bills_required']);
        $customer_care_number = sanitize_text_field((string) ($data['customer_care_number'] ?? ''));
        $is_range = !empty($data['is_range']);
        $flow_kind = $this->infer_flow_kind(
            $product_type,
            $redemption_mechanism,
            $lookup_bills_required,
            $is_range,
            (string) ($data['bundle_label'] ?? '')
        );

        // Snapshot existing cart if it has regular products
        if (WC()->cart && !WC()->cart->is_empty() && !$this->cart_has_only_recargas()) {
            $snapshot = [
                'cart' => WC()->session->get('cart'),
                'applied_coupons' => WC()->session->get('applied_coupons'),
            ];
            WC()->session->set('dc_cart_snapshot', $snapshot);
            WC()->cart->empty_cart();
        }

        $product_id = $this->get_or_create_base_product();
        if (!$product_id) {
            $this->api->log_operational_event('cart_add_failed', [
                'status' => 'error',
                'account_number' => (string) ($data['account_number'] ?? ''),
                'sku_code' => (string) ($data['sku_code'] ?? ''),
                'send_value' => (float) ($data['send_value'] ?? 0),
                'currency' => (string) ($data['send_currency_iso'] ?? ''),
                'raw_response' => ['reason' => 'base_product_missing'],
            ]);
            return new WP_Error('dc_product_error', 'No se pudo crear el producto base de recarga.');
        }

        $cart_item_data = [
            'dc_recarga'          => true,
            'dc_account_number'   => $data['account_number'],
            'dc_country_iso'      => $data['country_iso'],
            'dc_sku_code'         => $data['sku_code'],
            'dc_send_value'       => $data['send_value'],
            'dc_send_currency_iso'=> $data['send_currency_iso'],
            'dc_public_price'     => (float) ($data['public_price'] ?? $data['send_value']),
            'dc_public_currency_iso' => (string) ($data['public_price_currency'] ?? $data['send_currency_iso']),
            'dc_provider_name'    => $data['provider_name'],
            'dc_bundle_label'     => $data['bundle_label'],
            'dc_bundle_benefit'   => $data['bundle_benefit'] ?? '',
            'dc_bundle_id'        => $data['bundle_id'] ?? '',
            'dc_product_type'     => $product_type,
            'dc_redemption_mechanism' => $redemption_mechanism,
            'dc_lookup_bills_required' => $lookup_bills_required,
            'dc_customer_care_number' => $customer_care_number,
            'dc_is_range'         => $is_range,
            'dc_flow_kind'        => $flow_kind,
            'dc_settings'         => is_array($data['settings'] ?? null) ? $data['settings'] : [],
            'dc_bill_ref'         => sanitize_text_field((string) ($data['bill_ref'] ?? '')),
            'unique_key'          => md5($data['account_number'] . $data['sku_code'] . microtime()),
        ];

        if (function_exists('wc_clear_notices')) {
            wc_clear_notices();
        }

        $added = WC()->cart->add_to_cart($product_id, 1, 0, [], $cart_item_data);

        if (!$added) {
            $this->api->log_operational_event('cart_add_failed', [
                'status' => 'error',
                'account_number' => (string) ($data['account_number'] ?? ''),
                'sku_code' => (string) ($data['sku_code'] ?? ''),
                'send_value' => (float) ($data['send_value'] ?? 0),
                'currency' => (string) ($data['send_currency_iso'] ?? ''),
                'raw_response' => ['reason' => 'wc_add_to_cart_returned_false'],
            ]);
            return new WP_Error('dc_cart_error', $this->build_add_to_cart_error_message($product_id));
        }

        $this->api->log_operational_event('cart_added', [
            'status' => 'success',
            'account_number' => (string) ($data['account_number'] ?? ''),
            'sku_code' => (string) ($data['sku_code'] ?? ''),
            'send_value' => (float) ($data['send_value'] ?? 0),
            'currency' => (string) ($data['send_currency_iso'] ?? ''),
            'raw_response' => [
                'flow_kind' => $flow_kind,
                'bundle_id' => (string) ($data['bundle_id'] ?? ''),
            ],
        ]);

        return true;
    }

    private function build_add_to_cart_error_message($product_id) {
        $notice_messages = [];
        if (function_exists('wc_get_notices')) {
            $notices = wc_get_notices('error');
            if (is_array($notices)) {
                foreach ($notices as $notice) {
                    $raw = is_array($notice) ? (string) ($notice['notice'] ?? '') : (string) $notice;
                    $clean = trim(wp_strip_all_tags($raw));
                    if ($clean !== '') {
                        $notice_messages[] = $clean;
                    }
                }
            }
        }

        if (function_exists('wc_clear_notices')) {
            wc_clear_notices();
        }

        if (!empty($notice_messages)) {
            return implode(' | ', array_slice($notice_messages, 0, 2));
        }

        $product = function_exists('wc_get_product') ? wc_get_product($product_id) : null;
        if (!$product) {
            return 'No se pudo añadir la recarga al carrito (producto base no disponible).';
        }

        if (!$product->is_purchasable()) {
            return 'No se pudo añadir la recarga al carrito (producto no comprable en este entorno).';
        }

        return 'No se pudo añadir la recarga al carrito.';
    }

    public function force_recarga_product_purchasable($is_purchasable, $product) {
        if (!$product || !is_object($product) || !method_exists($product, 'get_id')) {
            return $is_purchasable;
        }

        $recarga_product_id = (int) get_option('dc_recargas_wc_product_id', 0);
        if ($recarga_product_id > 0 && (int) $product->get_id() === $recarga_product_id) {
            return true;
        }

        return $is_purchasable;
    }

    public function force_recarga_cart_item_purchasable($is_purchasable, $values, $product) {
        if (!empty($values['dc_recarga'])) {
            return true;
        }
        return $is_purchasable;
    }

    public function force_recarga_cart_item_in_stock($is_in_stock, $values, $product) {
        if (!empty($values['dc_recarga'])) {
            return true;
        }
        return $is_in_stock;
    }

    public function restore_recarga_cart_item_from_session($session_data, $values, $cart_item_key) {
        $is_dc_recarga = !empty($session_data['dc_recarga']) || !empty($values['dc_recarga']);
        if (!$is_dc_recarga) {
            return $session_data;
        }

        $product_id = (int) ($session_data['product_id'] ?? 0);
        $product = $product_id > 0 ? wc_get_product($product_id) : null;
        if (!$product || !$product->exists()) {
            $product_id = $this->get_or_create_base_product();
            $product = $product_id > 0 ? wc_get_product($product_id) : null;
        }

        if ($product && $product->exists()) {
            $session_data['product_id'] = (int) $product->get_id();
            $session_data['variation_id'] = 0;
            $session_data['data'] = $product;
            $session_data['dc_recarga'] = true;
            if (empty($session_data['quantity']) || (int) $session_data['quantity'] < 1) {
                $session_data['quantity'] = 1;
            }
        }

        $this->hydrate_recarga_cart_item_data($session_data);

        return $session_data;
    }

    public function diagnose_dc_cart_item_issues() {
        if (!WC()->cart) {
            return;
        }

        $has_dc = false;
        $issues = [];
        $healed = false;

        foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
            if (empty($cart_item['dc_recarga'])) {
                continue;
            }

            $has_dc = true;
            $item_issues = [];
            $product = $cart_item['data'] ?? null;

            if (!$product || !is_object($product) || !method_exists($product, 'exists') || !$product->exists()) {
                $base_product_id = $this->get_or_create_base_product();
                $base_product = $base_product_id > 0 ? wc_get_product($base_product_id) : null;
                if ($base_product && $base_product->exists()) {
                    WC()->cart->cart_contents[$cart_item_key]['product_id'] = (int) $base_product->get_id();
                    WC()->cart->cart_contents[$cart_item_key]['variation_id'] = 0;
                    WC()->cart->cart_contents[$cart_item_key]['data'] = $base_product;
                    $product = $base_product;
                    $healed = true;
                } else {
                    $item_issues[] = 'missing_product';
                }
            }

            if (!$product || !is_object($product) || !method_exists($product, 'is_purchasable') || !$product->is_purchasable()) {
                $item_issues[] = 'not_purchasable';
            }

            if (!$product || !is_object($product) || !method_exists($product, 'is_in_stock') || !$product->is_in_stock()) {
                $item_issues[] = 'out_of_stock';
            }

            if (!empty($item_issues)) {
                $issues[] = [
                    'cart_item_key' => (string) $cart_item_key,
                    'product_id' => (int) ($cart_item['product_id'] ?? 0),
                    'sku_code' => (string) ($cart_item['dc_sku_code'] ?? ''),
                    'issues' => array_values(array_unique($item_issues)),
                ];
            }
        }

        if ($healed && method_exists(WC()->cart, 'set_session')) {
            WC()->cart->set_session();
        }

        if (!$has_dc) {
            return;
        }

        // Heartbeat log: useful only while debugging checkout compatibility.
        $this->log_diagnostic('[DingConnect][checkout_cart_validation] ' . wp_json_encode([
            'issues_count' => count($issues),
            'has_dc_only_cart' => $this->cart_has_only_recargas(),
        ]));

        if (empty($issues)) {
            $this->relax_generic_dc_cart_notice_if_needed();
            return;
        }

        $error_notices = [];
        if (function_exists('wc_get_notices')) {
            foreach ((array) wc_get_notices('error') as $notice) {
                $raw = is_array($notice) ? (string) ($notice['notice'] ?? '') : (string) $notice;
                $clean = trim(wp_strip_all_tags($raw));
                if ($clean !== '') {
                    $error_notices[] = $clean;
                }
            }
        }

        $this->log_diagnostic('[DingConnect][checkout_cart_validation] ' . wp_json_encode([
            'issues' => $issues,
            'error_notices' => array_values(array_unique($error_notices)),
        ]), true);

        $this->relax_generic_dc_cart_notice_if_needed();
    }

    public function normalize_dc_cart_after_session_load($cart) {
        if (!$cart || !method_exists($cart, 'get_cart')) {
            return;
        }

        $updated = false;
        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            if (empty($cart_item['dc_recarga'])) {
                continue;
            }

            $product = $cart_item['data'] ?? null;
            if ($product && is_object($product) && method_exists($product, 'exists') && $product->exists()) {
                continue;
            }

            $base_product_id = $this->get_or_create_base_product();
            $base_product = $base_product_id > 0 ? wc_get_product($base_product_id) : null;
            if (!$base_product || !$base_product->exists()) {
                continue;
            }

            WC()->cart->cart_contents[$cart_item_key]['product_id'] = (int) $base_product->get_id();
            WC()->cart->cart_contents[$cart_item_key]['variation_id'] = 0;
            WC()->cart->cart_contents[$cart_item_key]['data'] = $base_product;
            WC()->cart->cart_contents[$cart_item_key]['dc_recarga'] = true;
            if (empty(WC()->cart->cart_contents[$cart_item_key]['quantity']) || (int) WC()->cart->cart_contents[$cart_item_key]['quantity'] < 1) {
                WC()->cart->cart_contents[$cart_item_key]['quantity'] = 1;
            }

            if ($this->hydrate_recarga_cart_item_data(WC()->cart->cart_contents[$cart_item_key])) {
                $updated = true;
            }

            $updated = true;
        }

        if ($updated && method_exists($cart, 'set_session')) {
            $cart->set_session();
            $this->log_diagnostic('[DingConnect][cart_loaded_from_session] normalizacion aplicada a items de recarga');
        }
    }

    public function cleanup_dc_only_generic_cart_notice_late() {
        $this->relax_generic_dc_cart_notice_if_needed();
    }

    public function stabilize_checkout_php_session_compat() {
        if (is_admin()) {
            return;
        }

        $is_checkout_page = function_exists('is_checkout') && is_checkout();
        $wc_ajax = isset($_REQUEST['wc-ajax']) ? sanitize_key((string) wp_unslash($_REQUEST['wc-ajax'])) : '';
        $is_checkout_ajax = ($wc_ajax === 'checkout');

        if (!$is_checkout_page && !$is_checkout_ajax) {
            return;
        }

        if (function_exists('session_status') && session_status() === PHP_SESSION_NONE) {
            @session_start();
            if (function_exists('session_status') && session_status() === PHP_SESSION_ACTIVE) {
                if (function_exists('session_write_close')) {
                    session_write_close();
                }
                $this->log_diagnostic('[DingConnect][checkout_env] php_session_iniciada_temprano_para_compatibilidad_checkout');
            }
        }
    }

    public function suppress_generic_cart_issue_error_for_dc_only($message) {
        if (!$this->is_dc_only_checkout_context()) {
            return $message;
        }

        $clean = trim(wp_strip_all_tags((string) $message));
        $is_suppressible_checkout_notice = $this->is_suppressible_dc_only_checkout_notice($clean);

        if ($is_suppressible_checkout_notice) {
            $this->log_diagnostic('[DingConnect][checkout_cart_validation] generic_error_suppressed_at_source');
            return '';
        }

        if ($clean !== '') {
            $this->log_diagnostic('[DingConnect][checkout_cart_validation] notice_no_suprimido: ' . $clean);
        }

        return $message;
    }

    private function relax_generic_dc_cart_notice_if_needed() {
        if (!$this->is_dc_only_checkout_context() || !function_exists('wc_get_notices') || !function_exists('wc_clear_notices') || !function_exists('wc_add_notice')) {
            return;
        }

        $errors = (array) wc_get_notices('error');
        if (empty($errors)) {
            return;
        }

        $keep = [];
        $removed = 0;

        foreach ($errors as $notice) {
            $raw = is_array($notice) ? (string) ($notice['notice'] ?? '') : (string) $notice;
            $clean = trim(wp_strip_all_tags($raw));
            $is_generic_cart_issue = $this->is_suppressible_dc_only_checkout_notice($clean);

            if ($is_generic_cart_issue) {
                $removed++;
                continue;
            }

            $keep[] = $clean;
        }

        if ($removed < 1) {
            return;
        }

        wc_clear_notices();
        foreach ($keep as $message) {
            if ($message !== '') {
                wc_add_notice($message, 'error');
            }
        }

        $this->log_diagnostic('[DingConnect][checkout_cart_validation] notice_generico_carrito_removido para carrito DC-only: ' . (string) $removed);
    }

    private function is_suppressible_dc_only_checkout_notice($message) {
        $clean = trim((string) $message);
        if ($clean === '') {
            return false;
        }

        $decoded = html_entity_decode($clean, ENT_QUOTES, 'UTF-8');
        $normalized_raw = function_exists('remove_accents') ? remove_accents($decoded) : $decoded;
        $normalized = strtolower($normalized_raw);
        $normalized = preg_replace('/\s+/u', ' ', $normalized);
        $normalized = trim((string) $normalized);

        $patterns = [
            'problemas con los articulos de tu carrito',
            'problemas con algunos articulos de tu carrito',
            'vuelve a la pagina del carrito',
            'resuelve los problemas antes de pagar',
            'para poder hacer un pedido',
            'el total del carro de compra debe ser de al menos',
            'el total del carrito debe ser de al menos',
            'pedido minimo',
            'compra minima',
            'problems with the items in your cart',
            'please go back to the cart page',
            'before checking out',
            'minimum order',
            'must be at least',
        ];

        foreach ($patterns as $pattern) {
            if (strpos($normalized, $pattern) !== false) {
                return true;
            }
        }

        $has_cart_problem = (strpos($normalized, 'problemas con') !== false || strpos($normalized, 'problems with') !== false)
            && (strpos($normalized, 'articulos de tu carrito') !== false || strpos($normalized, 'items in your cart') !== false);
        $has_return_to_cart = strpos($normalized, 'vuelve a la pagina del carrito') !== false
            || strpos($normalized, 'please go back to the cart page') !== false;
        $has_minimum_order_problem = (strpos($normalized, 'pedido') !== false || strpos($normalized, 'order') !== false)
            && ((strpos($normalized, 'al menos') !== false) || (strpos($normalized, 'at least') !== false) || (strpos($normalized, 'minim') !== false));
        $has_cart_total_minimum = (strpos($normalized, 'total del carro de compra') !== false || strpos($normalized, 'total del carrito') !== false)
            && (strpos($normalized, 'al menos') !== false || strpos($normalized, 'at least') !== false);

        if ($has_cart_problem || ($has_return_to_cart && strpos($normalized, 'pagar') !== false) || $has_minimum_order_problem || $has_cart_total_minimum) {
            return true;
        }

        return false;
    }

    private function is_dc_only_checkout_context() {
        if ($this->cart_has_only_recargas()) {
            return true;
        }

        if (!function_exists('WC') || !WC() || !WC()->session) {
            return false;
        }

        $session_cart = (array) WC()->session->get('cart', []);
        if (empty($session_cart)) {
            return false;
        }

        $has_dc = false;
        foreach ($session_cart as $item) {
            $is_dc = !empty($item['dc_recarga']);
            if (!$is_dc) {
                return false;
            }
            $has_dc = true;
        }

        return $has_dc;
    }

    /* ---------------------------------------------------------------
     * 5. Cart Customization Hooks
     * ------------------------------------------------------------- */

    /** Set the dynamic price for recarga cart items. */
    public function set_custom_price($cart) {
        if (is_admin() && !defined('DOING_AJAX')) return;
        if (!$cart || !method_exists($cart, 'get_cart')) return;

        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            if (!empty($cart_item['dc_recarga']) && isset($cart_item['dc_send_value'])) {
                $this->hydrate_recarga_cart_item_data($cart->cart_contents[$cart_item_key]);
                $cart_item = $cart->cart_contents[$cart_item_key];

                $public_price = isset($cart_item['dc_public_price']) ? (float) $cart_item['dc_public_price'] : 0.0;
                $public_currency = (string) ($cart_item['dc_public_currency_iso'] ?? ($cart_item['dc_send_currency_iso'] ?? ''));
                $send_value = isset($cart_item['dc_send_value']) ? (float) $cart_item['dc_send_value'] : 0.0;
                $send_currency = (string) ($cart_item['dc_send_currency_iso'] ?? '');

                $billing_price = $public_price > 0
                    ? $this->normalize_price_for_store_currency($public_price, $public_currency)
                    : $this->normalize_price_for_store_currency($send_value, $send_currency);

                if (isset($cart_item['data']) && is_object($cart_item['data']) && method_exists($cart_item['data'], 'set_price')) {
                    $cart_item['data']->set_price($billing_price);
                }
            }
        }
    }

    /** Display recarga details in cart/checkout line items. */
    public function display_cart_item_data($item_data, $cart_item) {
        if (empty($cart_item['dc_recarga'])) return $item_data;

        $benefit_text = trim((string) ($cart_item['dc_bundle_benefit'] ?? ''));
        $bundle_label = trim((string) ($cart_item['dc_bundle_label'] ?? ''));

        $item_data[] = ['key' => 'País', 'value' => strtoupper($cart_item['dc_country_iso'] ?? '')];
        $item_data[] = ['key' => 'Número beneficiario', 'value' => $cart_item['dc_account_number'] ?? ''];
        $item_data[] = ['key' => 'Operador', 'value' => $cart_item['dc_provider_name'] ?? ''];

        if ($benefit_text !== '') {
            $item_data[] = ['key' => 'Beneficios', 'value' => $benefit_text];
        }

        if ($bundle_label !== '' && strcasecmp($bundle_label, $benefit_text) !== 0) {
            $item_data[] = ['key' => 'Paquete', 'value' => $bundle_label];
        }

        $public_price = isset($cart_item['dc_public_price']) ? (float) $cart_item['dc_public_price'] : 0.0;
        $public_currency = (string) ($cart_item['dc_public_currency_iso'] ?? ($cart_item['dc_send_currency_iso'] ?? ''));
        if ($public_price > 0) {
            $item_data[] = ['key' => 'Precio al público', 'value' => sprintf('%s %.2f', $public_currency, $public_price)];
        }

        $item_data[] = ['key' => 'Moneda operación', 'value' => $cart_item['dc_send_currency_iso'] ?? ''];

        if (!empty($cart_item['dc_bill_ref'])) {
            $item_data[] = ['key' => 'Factura', 'value' => $cart_item['dc_bill_ref']];
        }

        if (!empty($cart_item['dc_settings']) && is_array($cart_item['dc_settings'])) {
            foreach ($cart_item['dc_settings'] as $setting) {
                if (!is_array($setting) || empty($setting['Name'])) {
                    continue;
                }

                $item_data[] = [
                    'key' => 'Dato ' . $setting['Name'],
                    'value' => (string) ($setting['Value'] ?? ''),
                ];
            }
        }

        return $item_data;
    }

    /** Override product name in cart with provider + bundle label. */
    public function custom_cart_item_name($name, $cart_item, $cart_item_key) {
        if (!empty($cart_item['dc_recarga'])) {
            $label    = $cart_item['dc_bundle_label'] ?? 'Recarga';
            $benefit  = trim((string) ($cart_item['dc_bundle_benefit'] ?? ''));
            $beneficiary = trim((string) ($cart_item['dc_account_number'] ?? ''));
            $display_name = '';
            if ($benefit !== '') {
                $display_name = $benefit;
            } else {
                $provider = $cart_item['dc_provider_name'] ?? '';
                $display_name = $provider ? $provider . ' - ' . $label : $label;
            }

            if ($beneficiary === '') {
                return esc_html($display_name);
            }

            return sprintf(
                '%s<br><small><strong>%s</strong> %s</small>',
                esc_html($display_name),
                esc_html__('Número beneficiario:', 'dingconnect-recargas'),
                esc_html($beneficiary)
            );
        }
        return $name;
    }

    private function hydrate_recarga_cart_item_data(&$cart_item) {
        if (!is_array($cart_item) || empty($cart_item['dc_recarga'])) {
            return false;
        }

        $matched_bundle = $this->find_saved_bundle_for_cart_item($cart_item);
        if (!is_array($matched_bundle)) {
            return false;
        }

        $updated = false;

        if (empty($cart_item['dc_bundle_id']) && !empty($matched_bundle['id'])) {
            $cart_item['dc_bundle_id'] = sanitize_text_field((string) $matched_bundle['id']);
            $updated = true;
        }

        if (empty($cart_item['dc_bundle_label']) && !empty($matched_bundle['label'])) {
            $cart_item['dc_bundle_label'] = sanitize_text_field((string) $matched_bundle['label']);
            $updated = true;
        }

        if (empty($cart_item['dc_provider_name']) && !empty($matched_bundle['provider_name'])) {
            $cart_item['dc_provider_name'] = sanitize_text_field((string) $matched_bundle['provider_name']);
            $updated = true;
        }

        if (empty($cart_item['dc_public_currency_iso']) && !empty($matched_bundle['public_price_currency'])) {
            $cart_item['dc_public_currency_iso'] = strtoupper(sanitize_text_field((string) $matched_bundle['public_price_currency']));
            $updated = true;
        }

        if ((!isset($cart_item['dc_public_price']) || (float) $cart_item['dc_public_price'] <= 0) && isset($matched_bundle['public_price'])) {
            $stored_public_price = (float) $matched_bundle['public_price'];
            if ($stored_public_price > 0) {
                $cart_item['dc_public_price'] = $stored_public_price;
                $updated = true;
            }
        }

        $benefit_text = $this->extract_bundle_benefit_for_checkout($matched_bundle);
        $current_benefit = trim((string) ($cart_item['dc_bundle_benefit'] ?? ''));
        $current_label = trim((string) ($cart_item['dc_bundle_label'] ?? ''));
        $current_sku = trim((string) ($cart_item['dc_sku_code'] ?? ''));
        if ($benefit_text !== '' && ($current_benefit === '' || strcasecmp($current_benefit, $current_label) === 0 || strcasecmp($current_benefit, $current_sku) === 0)) {
            $cart_item['dc_bundle_benefit'] = $benefit_text;
            $updated = true;
        }

        return $updated;
    }

    private function find_saved_bundle_for_cart_item(array $cart_item) {
        $bundles = get_option('dc_recargas_bundles', []);
        if (!is_array($bundles)) {
            $bundles = [];
        }
        if (empty($bundles)) {
            return null;
        }

        $bundle_id = sanitize_text_field((string) ($cart_item['dc_bundle_id'] ?? ''));
        $sku_code = sanitize_text_field((string) ($cart_item['dc_sku_code'] ?? ''));
        $country_iso = strtoupper(sanitize_text_field((string) ($cart_item['dc_country_iso'] ?? '')));

        if ($bundle_id !== '') {
            foreach ($bundles as $bundle) {
                if (!is_array($bundle)) {
                    continue;
                }

                $candidate_id = sanitize_text_field((string) ($bundle['id'] ?? ''));
                if ($candidate_id !== '' && $candidate_id === $bundle_id) {
                    return $bundle;
                }
            }
        }

        foreach ($bundles as $bundle) {
            if (!is_array($bundle)) {
                continue;
            }

            $candidate_sku = sanitize_text_field((string) ($bundle['sku_code'] ?? ''));
            if ($candidate_sku === '' || $candidate_sku !== $sku_code) {
                continue;
            }

            $candidate_country = strtoupper(sanitize_text_field((string) ($bundle['country_iso'] ?? '')));
            if ($country_iso !== '' && $candidate_country !== '' && $candidate_country !== $country_iso) {
                continue;
            }

            return $bundle;
        }

        return null;
    }

    private function extract_bundle_benefit_for_checkout(array $bundle) {
        $description = sanitize_text_field((string) ($bundle['description'] ?? ''));
        if ($description !== '') {
            return $description;
        }

        $legacy_receive = sanitize_text_field((string) ($bundle['receive'] ?? ''));
        if ($legacy_receive !== '') {
            return $legacy_receive;
        }

        $benefits = [];
        foreach ((array) ($bundle['benefits'] ?? []) as $benefit) {
            $clean = sanitize_text_field((string) $benefit);
            if ($clean !== '') {
                $benefits[] = $clean;
            }
        }

        return !empty($benefits) ? implode(', ', $benefits) : '';
    }

    private function normalize_price_for_store_currency($amount, $amount_currency) {
        $normalized_amount = (float) $amount;
        if ($normalized_amount <= 0) {
            return 0.0;
        }

        $source_currency = strtoupper(sanitize_text_field((string) $amount_currency));
        $store_currency = strtoupper(sanitize_text_field((string) get_option('woocommerce_currency', '')));
        if ($source_currency === '' || $store_currency === '' || $source_currency === $store_currency) {
            return $normalized_amount;
        }

        if (!class_exists('WOOMULTI_CURRENCY_Data') || !method_exists('WOOMULTI_CURRENCY_Data', 'get_ins')) {
            return $normalized_amount;
        }

        $multi_currency_settings = WOOMULTI_CURRENCY_Data::get_ins();
        if (!$multi_currency_settings || !method_exists($multi_currency_settings, 'get_list_currencies')) {
            return $normalized_amount;
        }

        $currencies = (array) $multi_currency_settings->get_list_currencies();
        $source_rate = isset($currencies[$source_currency]['rate']) ? (float) $currencies[$source_currency]['rate'] : 0.0;
        if ($source_rate <= 0) {
            return $normalized_amount;
        }

        return $normalized_amount / $source_rate;
    }

    /**
     * Avoid media attachment metadata lookups for synthetic recarga items.
     */
    public function suppress_recarga_cart_item_thumbnail($thumbnail, $cart_item, $cart_item_key) {
        if (!empty($cart_item['dc_recarga'])) {
            return '';
        }

        return $thumbnail;
    }

    /* ---------------------------------------------------------------
     * 6. Order Item Meta
     * ------------------------------------------------------------- */

    /** Persist recarga data from cart into order line item meta. */
    public function save_order_item_meta($item, $cart_item_key, $values, $order) {
        if (empty($values['dc_recarga'])) return;

        call_user_func([$item, 'add_meta_data'], '_dc_recarga',           'yes', true);
        call_user_func([$item, 'add_meta_data'], '_dc_account_number',    $values['dc_account_number'] ?? '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_country_iso',       $values['dc_country_iso'] ?? '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_sku_code',          $values['dc_sku_code'] ?? '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_send_value',        $values['dc_send_value'] ?? 0, true);
        call_user_func([$item, 'add_meta_data'], '_dc_send_currency_iso', $values['dc_send_currency_iso'] ?? '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_public_price',      $values['dc_public_price'] ?? ($values['dc_send_value'] ?? 0), true);
        call_user_func([$item, 'add_meta_data'], '_dc_public_currency_iso', $values['dc_public_currency_iso'] ?? ($values['dc_send_currency_iso'] ?? ''), true);
        call_user_func([$item, 'add_meta_data'], '_dc_provider_name',     $values['dc_provider_name'] ?? '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_bundle_label',      $values['dc_bundle_label'] ?? '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_bundle_benefit',    $values['dc_bundle_benefit'] ?? '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_product_type',      $values['dc_product_type'] ?? '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_redemption_mechanism', $values['dc_redemption_mechanism'] ?? '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_lookup_bills_required', !empty($values['dc_lookup_bills_required']) ? 'yes' : '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_customer_care_number', $values['dc_customer_care_number'] ?? '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_is_range',          !empty($values['dc_is_range']) ? 'yes' : '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_flow_kind',         $values['dc_flow_kind'] ?? '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_bill_ref',          $values['dc_bill_ref'] ?? '', true);
        call_user_func([$item, 'add_meta_data'], '_dc_settings',          !empty($values['dc_settings']) ? wp_json_encode($values['dc_settings']) : '', true);
    }

    /* ---------------------------------------------------------------
     * 7. Mandatory Registration (no guest checkout for recargas)
     * ------------------------------------------------------------- */

    /**
     * Force registration only for mixed carts (DC recargas + other products).
     * DC-only checkouts allow guest to keep the flow as simple as possible.
     */
    public function force_registration($registration_required) {
        if ($this->cart_has_recargas() && !$this->cart_has_only_recargas()) {
            return true;
        }
        return $registration_required;
    }

    public function disable_guest_checkout($value) {
        if ($this->cart_has_recargas() && !$this->cart_has_only_recargas()) {
            return 'no';
        }
        return $value;
    }

    /**
     * When the cart contains ONLY DC recargas, redirect /cart to /checkout
     * so the user never sees the generic cart page.
     */
    public function redirect_dc_only_cart_to_checkout() {
        if (!is_cart()) return;
        if (!$this->cart_has_only_recargas()) return;
        wp_safe_redirect(wc_get_checkout_url());
        exit;
    }

    public function handle_cart_restoration_fallback() {
        if (!WC()->session) return;
        
        $snapshot = WC()->session->get('dc_cart_snapshot');
        if (empty($snapshot)) return;

        $is_explicit_cancel = isset($_GET['dc_cancel_recharge']) && $_GET['dc_cancel_recharge'] === '1';
        
        if (!$is_explicit_cancel) {
            // Do not restore if we are in checkout or doing wc-ajax
            $is_checkout_page = function_exists('is_checkout') && is_checkout();
            $doing_ajax = function_exists('wp_doing_ajax') ? wp_doing_ajax() : (defined('DOING_AJAX') && DOING_AJAX);
            if ($is_checkout_page || $doing_ajax || isset($_GET['wc-ajax'])) {
                // Except if we are on the order-received page, the order is complete, we should restore it so they can continue shopping.
                $is_order_received = function_exists('is_wc_endpoint_url') && is_wc_endpoint_url('order-received');
                if ($is_order_received) {
                    $this->restore_cart_snapshot($snapshot);
                }
                return;
            }
        }

        // Proceed to restore
        $this->restore_cart_snapshot($snapshot);

        if ($is_explicit_cancel) {
            wp_safe_redirect(wc_get_cart_url());
            exit;
        }
    }

    private function restore_cart_snapshot($snapshot) {
        if (WC()->cart) {
            WC()->cart->empty_cart();
            if (!empty($snapshot['cart'])) {
                WC()->session->set('cart', $snapshot['cart']);
            }
            if (!empty($snapshot['applied_coupons'])) {
                WC()->session->set('applied_coupons', $snapshot['applied_coupons']);
            }
            // WooCommerce doesn't automatically re-load the cart contents from the session just by calling set() on the session.
            // By clearing cart_contents, the next calculate_totals or get_cart call will re-hydrate from session.
            WC()->cart->cart_contents = [];
            // Calling this directly forces the class to reload the cart from the session.
            if (method_exists(WC()->cart, 'get_cart_from_session')) {
                WC()->cart->get_cart_from_session();
            }
            WC()->cart->calculate_totals();
        }
        WC()->session->set('dc_cart_snapshot', null);
    }

    public function render_cancel_recharge_button() {
        if ($this->cart_has_only_recargas() && WC()->session && WC()->session->get('dc_cart_snapshot')) {
            $cancel_url = add_query_arg('dc_cancel_recharge', '1', wc_get_checkout_url());
            echo '<div class="dc-cancel-recharge-wrapper" style="margin-bottom: 20px;">';
            echo '<a href="' . esc_url($cancel_url) . '" class="button alt" style="background-color: #d9534f; color: #fff; text-align: center; display: block; padding: 10px;">' . esc_html__('Cancelar recarga y volver a la tienda', 'dingconnect-recargas') . '</a>';
            echo '</div>';
        }
    }

    private function cart_has_recargas() {
        if (!WC()->cart) return false;
        foreach (WC()->cart->get_cart() as $cart_item) {
            if (!empty($cart_item['dc_recarga'])) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns true only when EVERY item in the cart is a DC recarga.
     * Used to apply DC-specific checkout simplifications without affecting
     * regular WooCommerce products.
     */
    private function cart_has_only_recargas() {
        // WC cart is not ready before wp_loaded. Calling get_cart() before that
        // triggers wc_doing_it_wrong and cascades into other early-call errors
        // (e.g. when Mollie fires woocommerce_payment_gateways during woocommerce_init).
        if (!did_action('wp_loaded')) return false;
        if (!WC()->cart) return false;
        $items = WC()->cart->get_cart();
        if (empty($items)) return false;
        foreach ($items as $cart_item) {
            if (empty($cart_item['dc_recarga'])) return false;
        }
        return true;
    }

    public function filter_available_payment_gateways($gateways) {
        if (!is_array($gateways) || empty($gateways)) {
            return $gateways;
        }

        if (!$this->cart_has_recargas()) {
            return $gateways;
        }

        $options = $this->api->get_options();
        $payment_mode = sanitize_text_field((string) ($options['payment_mode'] ?? 'direct'));
        if ($payment_mode !== 'woocommerce') {
            return $gateways;
        }

        $allowed = array_values(array_unique(array_filter(array_map('sanitize_key', (array) ($options['woo_allowed_gateways'] ?? [])))));
        if (empty($allowed)) {
            return $gateways;
        }

        $allowed_map = array_fill_keys($allowed, true);

        $filtered = array_filter($gateways, function ($gateway, $gateway_id) use ($allowed_map) {
            return isset($allowed_map[sanitize_key((string) $gateway_id)]);
        }, ARRAY_FILTER_USE_BOTH);

        if (empty($filtered)) {
            $available_ids = array_map('sanitize_key', array_keys($gateways));
            $this->log_diagnostic('[DingConnect][checkout_gateways] bloqueo: allowed_gateways sin coincidencias disponibles. allowed=' . implode(',', $allowed) . ' available=' . implode(',', $available_ids), true);
            if (function_exists('wc_add_notice')) {
                $notice = __('No hay pasarelas habilitadas para completar recargas. Contacta soporte antes de pagar.', 'dingconnect-recargas');
                if (!function_exists('wc_has_notice') || !wc_has_notice($notice, 'error')) {
                    wc_add_notice($notice, 'error');
                }
            }
            return [];
        }

        $this->log_diagnostic('[DingConnect][checkout_gateways] gateways aplicadas para recarga: ' . implode(',', array_keys($filtered)));
        return $filtered;
    }

    public function filter_gateway_classes_for_dc_checkout($gateway_classes) {
        if (!is_array($gateway_classes) || empty($gateway_classes)) {
            return $gateway_classes;
        }

        if (!$this->is_checkout_request_context() || !$this->is_dc_only_checkout_context()) {
            return $gateway_classes;
        }

        $options = $this->api->get_options();
        $payment_mode = sanitize_text_field((string) ($options['payment_mode'] ?? 'direct'));
        if ($payment_mode !== 'woocommerce') {
            return $gateway_classes;
        }

        $allowed = array_values(array_unique(array_filter(array_map('sanitize_key', (array) ($options['woo_allowed_gateways'] ?? [])))));
        if (empty($allowed)) {
            return $gateway_classes;
        }

        $tropipay_allowed = in_array('tropipay', $allowed, true) || in_array('wc_tropipay', $allowed, true);
        if ($tropipay_allowed) {
            return $gateway_classes;
        }

        $filtered = [];
        $removed = false;
        foreach ($gateway_classes as $key => $gateway_class) {
            $key_norm = sanitize_key((string) $key);
            $class_norm = sanitize_key(is_string($gateway_class) ? $gateway_class : '');
            $is_tropipay = (strpos($key_norm, 'tropipay') !== false) || (strpos($class_norm, 'tropipay') !== false);
            if ($is_tropipay) {
                $removed = true;
                continue;
            }
            $filtered[$key] = $gateway_class;
        }

        if ($removed) {
            $this->log_diagnostic('[DingConnect][checkout_gateways] clase gateway Tropipay excluida en checkout DC-only por configuracion de pasarelas permitidas');
            return $filtered;
        }

        return $gateway_classes;
    }

    private function is_checkout_request_context() {
        if (is_admin()) {
            return false;
        }

        $is_checkout_page = function_exists('is_checkout') && is_checkout();
        $wc_ajax = isset($_REQUEST['wc-ajax']) ? sanitize_key((string) wp_unslash($_REQUEST['wc-ajax'])) : '';
        $is_checkout_ajax = in_array($wc_ajax, ['checkout', 'update_order_review'], true);

        return $is_checkout_page || $is_checkout_ajax;
    }

    private function should_hide_acfw_store_credit_ui() {
        if (!$this->is_checkout_request_context()) {
            return false;
        }

        if (!$this->cart_has_only_recargas()) {
            return false;
        }

        $options = $this->api->get_options();
        $payment_mode = sanitize_text_field((string) ($options['payment_mode'] ?? 'direct'));
        if ($payment_mode !== 'woocommerce') {
            return false;
        }

        return !empty($options['hide_acfw_store_credit_dc_only']);
    }

    public function maybe_hide_acfw_store_credit_ui() {
        if (!$this->should_hide_acfw_store_credit_ui()) {
            return;
        }

        ?>
        <style id="dc-hide-acfw-store-credit">
            .dc-hide-store-credit {
                display: none !important;
            }

            .woocommerce-checkout [class*="acfw"][class*="store-credit"],
            .woocommerce-checkout [class*="acfw"][class*="credit"],
            .woocommerce-checkout [id*="acfw"][id*="credit"] {
                display: none !important;
            }
        </style>
        <script id="dc-hide-acfw-store-credit-script">
            (function () {
                function normalize(text) {
                    return String(text || '')
                        .toLowerCase()
                        .normalize('NFD')
                        .replace(/[\u0300-\u036f]/g, '')
                        .replace(/\s+/g, ' ')
                        .trim();
                }

                function hasStoreCreditText(text) {
                    var value = normalize(text);
                    if (!value) {
                        return false;
                    }

                    return value.indexOf('apply store credit discounts') !== -1
                        || value.indexOf('available store credits') !== -1
                        || value.indexOf('introduce la cantidad de creditos en la tienda') !== -1
                        || value.indexOf('introduce la cantidad') !== -1
                        || value.indexOf('creditos en la tienda') !== -1;
                }

                function hideNode(node) {
                    if (!node || !node.classList) {
                        return;
                    }
                    node.classList.add('dc-hide-store-credit');
                }

                function findTarget(node) {
                    if (!node || !node.closest) {
                        return null;
                    }

                    return node.closest(
                        '.acfw-checkout-ui, .acfw-checkout-store-credit, .acfw-store-credits, .acfw-widget, [class*="acfw"], [id*="acfw"], .woocommerce-form-coupon-toggle, .wc-block-components-panel, .wc-block-components-totals-item, .woocommerce-checkout-review-order'
                    ) || node.parentElement;
                }

                function run() {
                    var selectors = [
                        '.acfw-checkout-ui',
                        '.acfw-checkout-store-credit',
                        '.acfw-store-credits',
                        '.acfw-widget',
                        '[class*="acfw"][class*="credit"]',
                        '[id*="acfw"][id*="credit"]',
                        'summary',
                        'label',
                        'h2',
                        'h3',
                        'p',
                        'span'
                    ];

                    for (var i = 0; i < selectors.length; i++) {
                        var nodes = document.querySelectorAll(selectors[i]);
                        for (var j = 0; j < nodes.length; j++) {
                            var node = nodes[j];
                            var className = normalize(node.className || '');
                            var idName = normalize(node.id || '');
                            var isAcfwCandidate = className.indexOf('acfw') !== -1 || idName.indexOf('acfw') !== -1;

                            if (isAcfwCandidate || hasStoreCreditText(node.textContent)) {
                                hideNode(findTarget(node));
                            }
                        }
                    }
                }

                run();

                if (typeof MutationObserver !== 'undefined') {
                    var observer = new MutationObserver(function () {
                        run();
                    });
                    observer.observe(document.body, { childList: true, subtree: true });
                }
            })();
        </script>
        <?php
    }

    /* ---------------------------------------------------------------
     * 8. Checkout Fields & Phone Login
     * ------------------------------------------------------------- */

    /**
     * Customize checkout fields.
     *
     * - DC-only cart: simplify to first name, last name, email and billing phone.
     *   All address/shipping/order fields are removed so the checkout is minimal.
     * - Mixed cart (DC + regular products): keep all WC fields, just enforce phone.
     */
    public function customize_checkout_fields($fields) {
        if (!$this->cart_has_recargas()) return $fields;

        if ($this->cart_has_only_recargas()) {
            // Minimal DC checkout: name + email + phone only
            $allowed_billing = ['billing_first_name', 'billing_last_name', 'billing_email', 'billing_phone'];

            if (isset($fields['billing']) && is_array($fields['billing'])) {
                foreach (array_keys($fields['billing']) as $key) {
                    if (!in_array($key, $allowed_billing, true)) {
                        unset($fields['billing'][$key]);
                    }
                }
            }

            // Shipping and order comment fields are not needed for virtual products
            $fields['shipping'] = [];
            $fields['order']    = [];
        }

        // Always ensure billing_phone is required and labelled clearly
        if (isset($fields['billing']['billing_phone'])) {
            $fields['billing']['billing_phone']['required']    = true;
            $fields['billing']['billing_phone']['priority']    = 30;
            $fields['billing']['billing_phone']['label']       = 'Tu número de teléfono';
            $fields['billing']['billing_phone']['placeholder'] = 'Ej: +34 600 000 000';
        }

        return $fields;
    }

    /**
     * Safety net: remove any WC address validation errors that may fire
     * even after fields are removed via the checkout_fields filter.
     * Only active for DC-only carts.
     */
    public function clear_address_validation_errors_for_dc($data, $errors) {
        if (!$this->cart_has_only_recargas()) return;

        $address_fields = [
            'billing_address_1', 'billing_address_2', 'billing_city',
            'billing_state', 'billing_postcode', 'billing_country', 'billing_company',
            'shipping_first_name', 'shipping_last_name', 'shipping_address_1',
            'shipping_address_2', 'shipping_city', 'shipping_state',
            'shipping_postcode', 'shipping_country',
        ];

        foreach ($address_fields as $field) {
            $errors->remove($field);
        }
    }

    /** Pre-fill billing phone from recarga data during registration. */
    public function prefill_customer_phone($customer_data) {
        if (!WC()->cart) return $customer_data;

        foreach (WC()->cart->get_cart() as $cart_item) {
            if (!empty($cart_item['dc_recarga']) && !empty($cart_item['dc_account_number'])) {
                $customer_data['billing_phone'] = sanitize_text_field($cart_item['dc_account_number']);
                break;
            }
        }

        return $customer_data;
    }

    /**
     * Allow login by phone number (billing_phone usermeta).
     * Uses direct DB query because WP has no usermeta-by-value lookup function.
     */
    public function authenticate_by_phone($user, $username, $password) {
        if ($user instanceof WP_User) return $user;

        $cleaned = preg_replace('/[^\d+]/', '', $username);
        if (strlen($cleaned) >= 8) {
            global $wpdb;
            $user_id = $wpdb->get_var($wpdb->prepare(
                "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = 'billing_phone' AND meta_value = %s LIMIT 1",
                $cleaned
            ));

            if ($user_id) {
                $phone_user = get_user_by('id', $user_id);
                if ($phone_user && wp_check_password($password, $phone_user->user_pass, $phone_user->ID)) {
                    return $phone_user;
                }
            }
        }

        return $user;
    }

    /* ---------------------------------------------------------------
     * 9. Order Processing - Execute Real DingConnect Transfer
     * ------------------------------------------------------------- */

    /**
     * Fire the real DingConnect transfer when payment is confirmed.
     *
     * IMPORTANT: The admin must enable "allow_real_recharge" in plugin settings
     * for real transfers to execute. Without it, send_transfer() forces
     * ValidateOnly=true regardless of what we pass here.
     */
    public function handle_payment_complete($order_id) {
        $this->process_recarga_on_payment($order_id, 'payment_complete');
    }

    public function handle_order_status_processing($order_id) {
        $this->process_recarga_on_payment($order_id, 'processing');
    }

    public function handle_order_status_completed($order_id) {
        $this->process_recarga_on_payment($order_id, 'completed');
    }

    public function process_recarga_on_payment($order_id, $trigger_stage = 'payment_complete') {
        $order = wc_get_order($order_id);
        if (!$order) return;

        if (!$this->should_process_order_for_trigger_stage($order, $trigger_stage)) {
            $this->api->log_operational_event('payment_stage_skipped', [
                'status' => 'pending',
                'order_id' => (int) $order->get_id(),
                'payment_method' => (string) call_user_func([$order, 'get_payment_method']),
                'raw_response' => [
                    'trigger_stage' => $trigger_stage,
                    'selected_stage' => $this->get_dispatch_stage_for_order($order),
                    'order_status' => $this->get_order_status_slug($order),
                ],
            ]);
            return;
        }

        if (!$order->is_paid()) {
            $order->add_order_note('DingConnect: se omitio despacho porque la orden aun no figura como pagada.');
            $this->api->log_operational_event('payment_not_effective', [
                'status' => 'pending',
                'order_id' => (int) $order->get_id(),
                'payment_method' => (string) call_user_func([$order, 'get_payment_method']),
                'raw_response' => ['reason' => 'order_not_paid'],
            ]);
            return;
        }

        $this->api->log_operational_event('payment_status_changed', [
            'status' => 'success',
            'order_id' => (int) $order->get_id(),
            'payment_method' => (string) call_user_func([$order, 'get_payment_method']),
            'raw_response' => [
                'hook' => sanitize_key((string) $trigger_stage),
                'order_status' => $this->get_order_status_slug($order),
            ],
        ]);

        $order->add_order_note(sprintf(
            'DingConnect: inicio de evaluacion post-pago (hook: %s, estado actual: %s).',
            sanitize_key((string) $trigger_stage),
            $this->get_order_status_slug($order)
        ));

        $has_recargas = false;
        $all_success  = true;
        $has_pending_retry = false;

        foreach ($order->get_items() as $item_id => $item) {
            if ($item->get_meta('_dc_recarga') !== 'yes') continue;

            $has_recargas = true;

            if ($this->is_item_already_successful($item)) {
                continue;
            }

            $sync_result = $this->sync_item_with_ding_status($order, $item);
            if (!empty($sync_result['success'])) {
                continue;
            }

            if (!empty($sync_result['pending'])) {
                $all_success = false;
                $has_pending_retry = true;
                $this->schedule_submitted_retry($order, $item, 'sync_on_payment');
                continue;
            }

            $attempt_result = $this->attempt_transfer_for_item($order, $item, false);

            if (!empty($attempt_result['pending_retry'])) {
                $has_pending_retry = true;
            }

            if (empty($attempt_result['success'])) {
                $all_success = false;
            }
        }

        if ($has_recargas) {
            if ($all_success && !$has_pending_retry) {
                call_user_func([$order, 'update_meta_data'], '_dc_recargas_processed', current_time('mysql'));
                call_user_func([$order, 'delete_meta_data'], '_dc_recargas_has_errors');
            } else {
                call_user_func([$order, 'update_meta_data'], '_dc_recargas_has_errors', 'yes');
            }

            if ($has_pending_retry) {
                $order->add_order_note('Hay recargas con reintento programado. Se intentara nuevamente segun configuracion.');
            } elseif (!$all_success) {
                $order->add_order_note('Algunas recargas fallaron. Revisa los detalles de cada item o ejecuta reconciliacion manual.');
            }

            $this->sync_order_status_with_recarga_outcome($order, sanitize_key((string) $trigger_stage));
            call_user_func([$order, 'save']);
        }
    }

    public function process_retry_transfer($order_id, $item_id) {
        $order = wc_get_order((int) $order_id);
        if (!$order || !$order->is_paid()) {
            return;
        }

        $order->add_order_note(sprintf(
            'DingConnect: ejecucion de reintento programado para item #%d.',
            (int) $item_id
        ));

        $item = $order->get_item((int) $item_id);
        if (!$item instanceof WC_Order_Item_Product) {
            $order->add_order_note(sprintf(
                'DingConnect: reintento omitido, item #%d no encontrado en la orden.',
                (int) $item_id
            ));
            return;
        }

        if ($item->get_meta('_dc_recarga') !== 'yes' || $this->is_item_already_successful($item)) {
            $order->add_order_note(sprintf(
                'DingConnect: reintento omitido para item #%d porque no es recarga o ya estaba confirmado.',
                (int) $item_id
            ));
            return;
        }

        $sync_result = $this->sync_item_with_ding_status($order, $item);
        if (!empty($sync_result['success'])) {
            $this->sync_order_status_with_recarga_outcome($order, 'retry_sync_success');
            call_user_func([$order, 'save']);
            return;
        }

        if (!empty($sync_result['pending'])) {
            $this->schedule_submitted_retry($order, $item, 'sync_on_retry');
            $this->sync_order_status_with_recarga_outcome($order, 'retry_sync_pending');
            call_user_func([$order, 'save']);
            return;
        }

        $this->attempt_transfer_for_item($order, $item, false);
        $this->sync_order_status_with_recarga_outcome($order, 'retry_send_transfer');
        call_user_func([$order, 'save']);
    }

    public function handle_order_terminal_failure($order_id) {
        $order = wc_get_order((int) $order_id);
        if (!$order instanceof WC_Order) {
            return;
        }

        $updated = false;
        foreach ($order->get_items() as $item) {
            if (!($item instanceof WC_Order_Item_Product)) {
                continue;
            }

            if ($item->get_meta('_dc_recarga') !== 'yes') {
                continue;
            }

            $status = strtolower((string) $item->get_meta('_dc_transfer_status'));
            if ($this->is_successful_transfer_status($status)) {
                continue;
            }

            $item_id = (int) call_user_func([$item, 'get_id']);
            wp_clear_scheduled_hook('dc_recargas_retry_transfer', [(int) $order->get_id(), $item_id]);
            call_user_func([$item, 'delete_meta_data'], '_dc_next_retry_at');

            if ($this->is_pending_transfer_status($status) || in_array($status, ['pending_retry', 'not_started', ''], true)) {
                call_user_func([$item, 'update_meta_data'], '_dc_transfer_status', 'cancelled_before_dispatch');
                call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_code', 'order_terminal_state');
                call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_context', 'order_terminal_state');
                call_user_func([$item, 'update_meta_data'], '_dc_transfer_error', 'Despacho cancelado: el pedido cambió a un estado terminal no pagado.');
            }

            call_user_func([$item, 'save']);
            $updated = true;
        }

        if ($updated) {
            $order->add_order_note('DingConnect: reintentos cancelados para recargas pendientes por cambio de estado del pedido a failed/cancelled/refunded.');
            call_user_func([$order, 'save']);
        }
    }

    public function register_manual_reconcile_action($actions) {
        $actions['dc_recargas_manual_reconcile'] = __('Reintentar recargas DingConnect', 'dingconnect-recargas');
        $actions['dc_resend_voucher'] = __('Reenviar Voucher (Email)', 'dingconnect-recargas');
        return $actions;
    }

    public function handle_resend_voucher_action($order) {
        if (!$order instanceof WC_Order) {
            return;
        }

        $order->add_order_note('DingConnect: inicio de reenvío de voucher manual solicitado por operador.');

        $processed = 0;
        foreach ($order->get_items() as $item_id => $item) {
            if ($item->get_meta('_dc_recarga') !== 'yes') {
                continue;
            }

            if ($this->is_item_already_successful($item)) {
                $voucher_hash = (string) $item->get_meta('_dc_voucher_hash');
                if ($voucher_hash !== '') {
                    $this->voucher_outbox->enqueue((int) $order->get_id(), (int) $item->get_id(), $voucher_hash);
                    $processed++;
                }
            }
        }

        if ($processed > 0) {
            $order->add_order_note(sprintf('DingConnect: %d email(s) de voucher encolado(s) para reenvío manual.', $processed));
        } else {
            $order->add_order_note('DingConnect: reenvío manual cancelado (no hay recargas exitosas con voucher generado).');
        }
    }

    public function handle_manual_reconcile_action($order) {
        if (!$order instanceof WC_Order) {
            return;
        }

        $order->add_order_note('DingConnect: inicio de reconciliacion manual solicitada por operador.');

        $processed = 0;
        foreach ($order->get_items() as $item_id => $item) {
            if ($item->get_meta('_dc_recarga') !== 'yes') {
                continue;
            }

            if ($this->is_item_already_successful($item)) {
                continue;
            }

            $sync_result = $this->sync_item_with_ding_status($order, $item);
            if (!empty($sync_result['success'])) {
                $processed++;
                continue;
            }

            if (!empty($sync_result['pending'])) {
                $this->schedule_submitted_retry($order, $item, 'manual_reconcile');
                $processed++;
                continue;
            }

            $this->attempt_transfer_for_item($order, $item, true);
            $processed++;
        }

        if ($processed > 0) {
            $order->add_order_note(sprintf('Reconciliacion manual ejecutada para %d item(s) DingConnect.', $processed));
            $this->sync_order_status_with_recarga_outcome($order, 'manual_reconcile');
            call_user_func([$order, 'save']);
        } else {
            $order->add_order_note('DingConnect: reconciliacion manual sin items pendientes para procesar.');
        }
    }

    /* ---------------------------------------------------------------
     * 10. Admin Display: Recarga Meta on Order Page
     * ------------------------------------------------------------- */

    public function display_order_item_recarga_meta($item_id, $item, $product) {
        if (!($item instanceof WC_Order_Item_Product)) return;
        if ($item->get_meta('_dc_recarga') !== 'yes') return;

        $fields = [
            '_dc_account_number'  => 'Teléfono',
            '_dc_country_iso'     => 'País',
            '_dc_provider_name'   => 'Operador',
            '_dc_bundle_benefit'  => 'Beneficios',
            '_dc_bundle_label'    => 'Paquete',
            '_dc_public_price'    => 'Precio al público',
            '_dc_public_currency_iso' => 'Moneda precio público',
            '_dc_send_value'      => 'Coste Ding',
            '_dc_send_currency_iso' => 'Moneda operación',
            '_dc_transfer_ref'    => 'Ref. DingConnect',
            '_dc_distributor_ref' => 'Ref. Distribuidor',
            '_dc_transfer_status' => 'Estado transferencia',
            '_dc_transfer_http_status' => 'HTTP status',
            '_dc_transfer_error_code'  => 'Código error Ding',
            '_dc_transfer_error_context' => 'Contexto error',
            '_dc_transfer_error'  => 'Mensaje error',
        ];

        echo '<div class="dc-order-meta" style="margin-top:8px;padding:8px;background:#f8fafc;border-radius:6px;font-size:12px;">';
        echo '<strong style="display:block;margin-bottom:4px;color:#1e3a8a;">Datos de Recarga DingConnect</strong>';

        foreach ($fields as $meta_key => $label) {
            $value = $item->get_meta($meta_key);

            if ($meta_key === '_dc_public_price' && $value !== '') {
                $public_currency = (string) $item->get_meta('_dc_public_currency_iso');
                $value = sprintf('%s %.2f', $public_currency !== '' ? $public_currency : 'EUR', (float) $value);
            }

            if ($meta_key === '_dc_send_value' && $value !== '') {
                $send_currency = (string) $item->get_meta('_dc_send_currency_iso');
                $value = sprintf('%s %.2f', $send_currency !== '' ? $send_currency : 'EUR', (float) $value);
            }

            if ($value) {
                $is_error_field = in_array($meta_key, ['_dc_transfer_error', '_dc_transfer_error_code', '_dc_transfer_http_status', '_dc_transfer_error_context'], true);
                $css = $is_error_field ? 'color:#991b1b;' : '';
                echo '<div style="' . $css . '"><span style="color:#64748b;">' . esc_html($label) . ':</span> ' . esc_html($value) . '</div>';
            }
        }

        // Fase 3: Aviso administrativo de posible drift de catálogo
        $error_code_meta     = strtolower((string) $item->get_meta('_dc_transfer_error_code'));
        $val_fingerprint_raw = (string) $item->get_meta('_dc_validation_fingerprint');
        $val_fp              = $val_fingerprint_raw !== '' ? json_decode($val_fingerprint_raw, true) : [];
        $local_invalid       = is_array($val_fp) && isset($val_fp['result']) && $val_fp['result'] === 'invalid';
        $is_drift_error      = in_array($error_code_meta, ['parameteroutofrange', 'sendvalue', 'amount_out_of_range', 'amount_fixed_only'], true);

        if ($local_invalid || $is_drift_error) {
            $drift_send  = is_array($val_fp) && isset($val_fp['send_value']) ? sprintf('%.2f', (float) $val_fp['send_value']) : '-';
            $drift_min   = is_array($val_fp) && isset($val_fp['min'])        ? sprintf('%.2f', (float) $val_fp['min'])        : null;
            $drift_max   = is_array($val_fp) && isset($val_fp['max'])        ? sprintf('%.2f', (float) $val_fp['max'])        : null;
            $drift_fixed = is_array($val_fp) && isset($val_fp['fixed'])      ? sprintf('%.2f', (float) $val_fp['fixed'])      : null;
            $drift_mode  = is_array($val_fp) && isset($val_fp['mode'])       ? (string) $val_fp['mode']                       : '-';

            echo '<div style="margin-top:8px;padding:8px;background:#fef2f2;border-left:3px solid #dc2626;border-radius:4px;font-size:12px;">';
            echo '<strong style="color:#dc2626;">&#9888; Posible drift de catálogo detectado</strong>';
            echo '<div style="margin-top:4px;color:#7f1d1d;">El monto enviado no coincide con los rangos del bundle guardado localmente. Esto puede indicar que el catálogo DingConnect cambió sin refrescar los bundles en el plugin.</div>';
            echo '<div><span style="color:#64748b;">Modo:</span> ' . esc_html($drift_mode) . '</div>';
            echo '<div><span style="color:#64748b;">Valor enviado:</span> ' . esc_html($drift_send) . '</div>';
            if ($drift_min !== null && $drift_max !== null) {
                echo '<div><span style="color:#64748b;">Rango permitido:</span> ' . esc_html($drift_min) . ' &ndash; ' . esc_html($drift_max) . '</div>';
            } elseif ($drift_fixed !== null) {
                echo '<div><span style="color:#64748b;">Monto fijo esperado:</span> ' . esc_html($drift_fixed) . '</div>';
            }
            echo '<div style="margin-top:4px;"><strong>Acción:</strong> Verifica y refresca los bundles del plugin, luego usa "Reintentar recargas DingConnect" en las acciones del pedido.</div>';
            echo '</div>';
        }

        echo '</div>';
    }

    public function render_thankyou_voucher_summary($order_id) {
        $order = wc_get_order((int) $order_id);
        if (!$order) {
            return;
        }

        $status_synced = $this->force_sync_order_status_on_thankyou($order);

        $options = $this->api->get_options();
        $voucher_v2_enabled = !empty($options['voucher_v2_enabled']);

        $summary = $this->build_recarga_status_summary($order);
        $all_success = ($summary['total'] > 0 && $summary['success'] === $summary['total']);
        $has_pending = $this->order_has_pending_recargas($order);
        $has_errors = $this->order_has_error_recargas($order);
        $has_dc_items = false;

        ob_start();
        
        // Contenedor del Modal
        echo '<div id="dc-voucher-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.6); z-index:99999; align-items:center; justify-content:center;">';
        echo '<div class="dc-voucher-modal-content" style="background:#fff; padding:25px; border-radius:12px; max-width:500px; width:90%; max-height:90vh; overflow-y:auto; box-shadow: 0 10px 25px rgba(0,0,0,0.2); position:relative;">';
        echo '<button onclick="document.getElementById(\'dc-voucher-modal\').style.display=\'none\'" style="position:absolute; top:15px; right:15px; background:none; border:none; font-size:24px; cursor:pointer; color:#64748b;">&times;</button>';
        
        echo '<div class="dc-voucher-modal-title" style="text-align:center; margin-bottom:20px;">';
        echo '<h2 style="margin:0; color:#1e293b; font-size:1.5em;">Resumen final de tu compra Cubakilos</h2>';
        echo '</div>';

        if ($all_success) {
            echo '<p class="dc-voucher-modal-success" style="margin:0 0 14px;color:#166534;background:#dcfce7;padding:10px;border-radius:6px;text-align:center;font-weight:600;">Tu recarga fue exitosa. Guarda este comprobante con el ID de transacción como referencia.</p>';
        }
        if ($has_pending && !$all_success) {
            echo '<p class="dc-voucher-modal-warning" style="margin:0 0 14px;color:#7c2d12;background:#ffedd5;padding:10px;border-radius:6px;">Tu pedido contiene operaciones pendientes. No repitas la compra mientras el estado siga Submitted o Pending; el sistema seguirá conciliando según la política configurada.</p>';
        }
        if ($has_errors) {
            echo '<p class="dc-voucher-modal-warning" style="margin:0 0 14px;color:#991b1b;background:#fee2e2;padding:10px;border-radius:6px;">Una o más recargas no pudieron confirmarse. No repitas la compra de inmediato: revisa tu correo y, si el problema persiste, contacta soporte indicando tu número de pedido.</p>';
        }

        if ($voucher_v2_enabled) {
            foreach ($order->get_items() as $item) {
                if ($item->get_meta('_dc_recarga') === 'yes') {
                    $has_dc_items = true;
                    $voucher = $this->voucher_service->get_item_voucher_v2($item);
                    if ($voucher) {
                        if (!isset($voucher['transaction_id']) || (string) ($voucher['transaction_id'] ?? '') === '') {
                            $voucher['transaction_id'] = (string) ($voucher['transfer_ref'] ?? $item->get_meta('_dc_transfer_ref'));
                        }
                        if (!isset($voucher['status']) || (string) ($voucher['status'] ?? '') === '') {
                            $voucher['status'] = (string) $item->get_meta('_dc_transfer_status');
                        }
                        if (!isset($voucher['beneficiary']) || (string) ($voucher['beneficiary'] ?? '') === '') {
                            $voucher['beneficiary'] = (string) $item->get_meta('_dc_account_number');
                        }
                        if (!isset($voucher['public_price']) || (float) ($voucher['public_price'] ?? 0) <= 0) {
                            $voucher['public_price'] = (float) $item->get_meta('_dc_public_price');
                        }
                        if (!isset($voucher['public_currency']) || (string) ($voucher['public_currency'] ?? '') === '') {
                            $voucher['public_currency'] = (string) $item->get_meta('_dc_public_currency_iso');
                        }
                        if (!isset($voucher['amount_sent_currency']) || (string) ($voucher['amount_sent_currency'] ?? '') === '') {
                            $voucher['amount_sent_currency'] = (string) $item->get_meta('_dc_send_currency_iso');
                        }
                        if (!isset($voucher['country_iso']) || (string) ($voucher['country_iso'] ?? '') === '') {
                            $voucher['country_iso'] = (string) $item->get_meta('_dc_country_iso');
                        }
                        if (!isset($voucher['bundle']) || (string) ($voucher['bundle'] ?? '') === '') {
                            $voucher['bundle'] = (string) $item->get_meta('_dc_bundle_label');
                        }
                        echo $this->voucher_renderer->render_html($voucher);
                    }
                }
            }
        } else {
            foreach ($order->get_items() as $item) {
                if ($item->get_meta('_dc_recarga') !== 'yes') {
                    continue;
                }
                $payload = $this->get_item_voucher_payload($item);
                $public_price = (float) $item->get_meta('_dc_public_price');
                $public_currency = (string) $item->get_meta('_dc_public_currency_iso');
                $send_currency = (string) $item->get_meta('_dc_send_currency_iso');
                if ($public_price <= 0) {
                    $public_price = (float) $item->get_meta('_dc_send_value');
                }
                if ($public_currency === '') {
                    $public_currency = $send_currency;
                }
                $voucher = [
                    'contract_version' => 'voucher.legacy',
                    'transaction_id' => (string) ($payload['transaction_id'] ?? $item->get_meta('_dc_transfer_ref')),
                    'status' => (string) ($payload['status'] ?? $item->get_meta('_dc_transfer_status')),
                    'operator' => (string) ($payload['operator'] ?? $item->get_meta('_dc_provider_name')),
                    'beneficiary' => (string) ($payload['beneficiary_phone'] ?? $item->get_meta('_dc_account_number')),
                    'public_price' => $public_price,
                    'public_currency' => $public_currency,
                    'amount_sent' => (float) $item->get_meta('_dc_send_value'),
                    'amount_sent_currency' => $send_currency,
                    'amount_received' => (float) ($payload['amount_received'] ?? 0),
                    'country_iso' => (string) $item->get_meta('_dc_country_iso'),
                    'bundle' => (string) $item->get_meta('_dc_bundle_label'),
                    'timestamp' => (string) ($payload['timestamp'] ?? current_time('mysql')),
                    'receipt_text' => (string) ($payload['receipt_text'] ?? ''),
                    'receipt_params' => (array) ($payload['receipt_params'] ?? []),
                    'bill_ref' => (string) ($payload['bill_ref'] ?? $item->get_meta('_dc_bill_ref')),
                ];

                $has_dc_items = true;
                echo $this->voucher_renderer->render_html($voucher);
            }
        }

        echo '<div class="dc-voucher-modal-actions" style="text-align:center; margin-top:20px; display:flex; gap:10px; justify-content:center; flex-wrap:wrap;">';
        echo '<button onclick="document.getElementById(\'dc-voucher-modal\').style.display=\'none\'" style="background:#2563eb; color:#fff; border:none; padding:10px 20px; border-radius:6px; font-weight:600; cursor:pointer;">Cerrar</button>';
        echo '<button onclick="window.print()" style="background:#475569; color:#fff; border:none; padding:10px 20px; border-radius:6px; font-weight:600; cursor:pointer;">Guardar PDF</button>';
        echo '</div>';

        echo '</div></div>';

        // Estilos para la impresión del modal como PDF
        echo '<style>
        @media print {
            @page { size: A6 portrait; margin: 8mm; }

            html, body { height: auto !important; }
            body { margin: 0 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }

            body * { visibility: hidden; }
            #dc-voucher-modal, #dc-voucher-modal * { visibility: visible; }

            #dc-voucher-modal {
                position: static !important;
                left: auto !important;
                top: auto !important;
                width: auto !important;
                height: auto !important;
                background: transparent !important;
                display: block !important;
                padding: 0 !important;
            }

            .dc-voucher-modal-content {
                box-shadow: none !important;
                border-radius: 0 !important;
                max-height: none !important;
                overflow: visible !important;
                padding: 0 !important;

                width: 89mm !important;
                max-width: 89mm !important;
                margin: 0 auto !important;
            }

            .dc-voucher-modal-title,
            .dc-voucher-modal-warning,
            .dc-voucher-modal-actions,
            #dc-voucher-modal button {
                display: none !important;
            }

            .dc-voucher-container {
                margin-top: 0 !important;
                padding: 0 !important;
                border: none !important;
                background: #fff !important;
                border-radius: 0 !important;
                break-after: page;
                page-break-after: always;
            }
            .dc-voucher-container:last-of-type {
                break-after: auto;
                page-break-after: auto;
            }

            .dc-voucher-container h3 {
                margin: 0 0 8px 0 !important;
                font-size: 14px !important;
                letter-spacing: 0 !important;
            }

            .dc-voucher-container table { font-size: 12px !important; }
            .dc-voucher-container th {
                width: 45% !important;
                padding: 6px 0 !important;
                color: #475569 !important;
                border-bottom: 1px solid #e2e8f0 !important;
            }
            .dc-voucher-container td {
                padding: 6px 0 !important;
                border-bottom: 1px solid #e2e8f0 !important;
            }
        }
        </style>';

        // Script para abrir automáticamente
        echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            var modal = document.getElementById("dc-voucher-modal");
            if (modal) {
                modal.style.display = "flex";
            }
        });
        </script>';

        // Botón en la página para reabrir
        echo '<section class="woocommerce-order-details" style="margin-top:22px;">';
        echo '<button onclick="document.getElementById(\'dc-voucher-modal\').style.display=\'flex\'" class="button alt" style="width:100%; padding:15px; font-size:1.1em; border-radius:8px;">Ver Resumen de Compra Cubakilos</button>';
        echo '</section>';

        $html = ob_get_clean();

        if ($has_dc_items) {
            echo $html;
        }
    }

    public function inject_voucher_meta_into_email($fields, $sent_to_admin, $order) {
        if (!$order instanceof WC_Order) {
            return $fields;
        }

        $voucher_rows = $this->collect_order_voucher_rows($order);
        if (empty($voucher_rows)) {
            return $fields;
        }

        $fields['dc_recargas_voucher_summary'] = [
            'label' => __('Resumen de recarga', 'dingconnect-recargas'),
            'value' => implode(' | ', $voucher_rows),
        ];

        $summary = $this->build_recarga_status_summary($order);
        if (($summary['error'] ?? 0) > 0) {
            $fields['dc_recargas_next_steps'] = [
                'label' => __('Siguientes pasos', 'dingconnect-recargas'),
                'value' => 'Detectamos recargas no confirmadas. No repitas la compra de inmediato; responde a este correo o contacta soporte con tu número de pedido.',
            ];
        } elseif (($summary['pending'] ?? 0) > 0) {
            $fields['dc_recargas_next_steps'] = [
                'label' => __('Siguientes pasos', 'dingconnect-recargas'),
                'value' => 'Tu pedido tiene recargas en validación. No repitas la compra mientras estén en estado pendiente; continuaremos la conciliación automáticamente.',
            ];
        }

        return $fields;
    }

    /* ---------------------------------------------------------------
     * Helpers
     * ------------------------------------------------------------- */

    /**
     * Valida el monto del item contra el bundle guardado ANTES de llamar al proveedor.
     * Construye y persiste una huella de validación en el item para trazabilidad.
     *
    * @param mixed $item
     * @return true|WP_Error  true si el monto es válido; WP_Error con detalles si está fuera de rango.
     */
    private function validate_send_value_from_item($item) {
        $sku_code    = (string) $item->get_meta('_dc_sku_code');
        $country_iso = strtoupper((string) $item->get_meta('_dc_country_iso'));
        $send_value  = (float)  $item->get_meta('_dc_send_value');
        $bundle_id   = (string) $item->get_meta('_dc_bundle_id');

        // Construir huella de validación desde los datos del bundle guardado localmente
        $bundle = $this->api->find_bundle_for_amount_validation($sku_code, $country_iso, $bundle_id);
        $fingerprint = [
            'validated_at' => current_time('mysql'),
            'send_value'   => $send_value,
            'sku_code'     => strtoupper($sku_code),
            'mode'         => 'unknown',
        ];

        if (!empty($bundle)) {
            $options          = $this->api->get_options();
            $allow_manual     = (sanitize_key((string) ($options['manual_amount_mode'] ?? 'range_products')) === 'range_products');
            $sv               = (float) ($bundle['send_value'] ?? 0);
            $min              = isset($bundle['minimum_send_value']) ? (float) $bundle['minimum_send_value'] : $sv;
            $max              = isset($bundle['maximum_send_value']) ? (float) $bundle['maximum_send_value'] : $sv;
            $bundle_allow     = array_key_exists('allow_manual_amount', $bundle) ? !empty($bundle['allow_manual_amount']) : true;
            $is_range         = $allow_manual && $bundle_allow && (!empty($bundle['is_range']) || abs($max - $min) > 0.00001);
            $fingerprint['mode'] = $is_range ? 'range' : 'fixed';
            if ($is_range) {
                $fingerprint['min'] = $min;
                $fingerprint['max'] = $max;
            } else {
                $fingerprint['fixed'] = $sv;
            }
        }

        $result = $this->api->validate_send_value_against_bundle($sku_code, $country_iso, $send_value, $bundle_id);

        $fingerprint['result'] = is_wp_error($result) ? 'invalid' : 'valid';
        if (is_wp_error($result)) {
            $err_data = $result->get_error_data();
            $fingerprint['error_code'] = (string) ($err_data['code'] ?? 'validation_failed');
        }
        if (is_object($item) && method_exists($item, 'update_meta_data')) {
            call_user_func([$item, 'update_meta_data'], '_dc_validation_fingerprint', wp_json_encode($fingerprint));
        }

        return $result;
    }

    /**
     * En productos de monto fijo, fuerza el send_value técnico del bundle antes del despacho.
     * Esto evita que variaciones del checkout/metadatos terminen enviando a Ding un monto distinto.
     *
     * @param WC_Order              $order
     * @param WC_Order_Item_Product $item
     * @param float                 $send_value
     * @param string                $send_currency_iso
     * @return array{send_value: float, send_currency_iso: string, normalized: bool}
     */
    private function normalize_fixed_send_value_for_dispatch($order, WC_Order_Item_Product $item, $send_value, $send_currency_iso) {
        $send_value = (float) $send_value;
        $send_currency_iso = (string) $send_currency_iso;

        $sku_code = (string) $item->get_meta('_dc_sku_code');
        $country_iso = strtoupper((string) $item->get_meta('_dc_country_iso'));
        $bundle_id = (string) $item->get_meta('_dc_bundle_id');
        $bundle = $this->api->find_bundle_for_amount_validation($sku_code, $country_iso, $bundle_id);

        if (!is_array($bundle) || empty($bundle)) {
            return [
                'send_value' => $send_value,
                'send_currency_iso' => $send_currency_iso,
                'normalized' => false,
            ];
        }

        $options = $this->api->get_options();
        $allow_manual = (sanitize_key((string) ($options['manual_amount_mode'] ?? 'range_products')) === 'range_products');
        $bundle_send_value = (float) ($bundle['send_value'] ?? 0);
        $min_send_value = isset($bundle['minimum_send_value']) ? (float) $bundle['minimum_send_value'] : $bundle_send_value;
        $max_send_value = isset($bundle['maximum_send_value']) ? (float) $bundle['maximum_send_value'] : $bundle_send_value;
        $bundle_allow_manual = array_key_exists('allow_manual_amount', $bundle) ? !empty($bundle['allow_manual_amount']) : true;
        $is_range = $allow_manual && $bundle_allow_manual && (!empty($bundle['is_range']) || abs($max_send_value - $min_send_value) > 0.00001);

        if ($is_range || $bundle_send_value <= 0 || abs($send_value - $bundle_send_value) <= 0.00001) {
            return [
                'send_value' => $send_value,
                'send_currency_iso' => $send_currency_iso,
                'normalized' => false,
            ];
        }

        $normalized_currency = strtoupper(sanitize_text_field((string) ($bundle['send_currency_iso'] ?? $send_currency_iso)));
        $original_send_value = (float) $send_value;

        $existing_original = $item->get_meta('_dc_send_value_original');
        if ((string) $existing_original === '') {
            call_user_func([$item, 'update_meta_data'], '_dc_send_value_original', $original_send_value);
        }
        call_user_func([$item, 'update_meta_data'], '_dc_send_value', $bundle_send_value);
        if ($normalized_currency !== '') {
            call_user_func([$item, 'update_meta_data'], '_dc_send_currency_iso', $normalized_currency);
        }
        call_user_func([$item, 'save']);

        $order->add_order_note(sprintf(
            'DingConnect: normalización de monto fijo aplicada en item #%d (SKU: %s). Monto pedido: %.2f -> Monto enviado a Ding: %.2f.',
            (int) $item->get_id(),
            $sku_code,
            $original_send_value,
            $bundle_send_value
        ));

        $this->api->log_operational_event('dispatch_send_value_normalized_fixed', [
            'status' => 'normalized',
            'order_id' => (int) $order->get_id(),
            'item_id' => (int) $item->get_id(),
            'account_number' => (string) $item->get_meta('_dc_account_number'),
            'sku_code' => $sku_code,
            'send_value' => $bundle_send_value,
            'currency' => $normalized_currency,
            'raw_response' => [
                'original_send_value' => $original_send_value,
                'bundle_fixed_send_value' => $bundle_send_value,
                'bundle_id' => $bundle_id,
            ],
        ]);

        return [
            'send_value' => $bundle_send_value,
            'send_currency_iso' => $normalized_currency !== '' ? $normalized_currency : $send_currency_iso,
            'normalized' => true,
        ];
    }

    private function is_item_already_successful($item) {
        $status = strtolower((string) $item->get_meta('_dc_transfer_status'));
        return $this->is_successful_transfer_status($status);
    }

    /**
     * Dispara el email de confirmación de recarga al cliente.
     * Delega al sistema de emails de WooCommerce (wp_mail + cualquier SMTP plugin activo).
     *
     * @param WC_Order                  $order
     * @param WC_Order_Item_Product     $item
     * @param array                     $snapshot  Snapshot del transfer.
     */
    private function send_recarga_confirmacion_email($order, $item, array $snapshot) {
        $options = $this->api->get_options();
        if (empty($options['voucher_outbox_enabled'])) {
            $emails = WC()->mailer()->get_emails();
            if (isset($emails['WC_DC_Email_Recarga_Confirmacion'])) {
                $emails['WC_DC_Email_Recarga_Confirmacion']->trigger($order->get_id(), $item, $snapshot);
            }
            return;
        }
        
        $voucher_hash = (string) $item->get_meta('_dc_voucher_hash');
        if ($voucher_hash !== '') {
            $this->voucher_outbox->enqueue((int) $order->get_id(), (int) $item->get_id(), $voucher_hash);
        }
    }

    private function attempt_transfer_for_item($order, $item, $manual = false) {
        $account_number = (string) $item->get_meta('_dc_account_number');
        $sku_code = (string) $item->get_meta('_dc_sku_code');
        $send_value = (float) $item->get_meta('_dc_send_value');
        $send_currency_iso = (string) $item->get_meta('_dc_send_currency_iso');
        $bill_ref = (string) $item->get_meta('_dc_bill_ref');
        $settings = json_decode((string) $item->get_meta('_dc_settings'), true);
        if (!is_array($settings)) {
            $settings = [];
        }

        if (!$this->is_order_payment_method_allowed_for_recargas($order)) {
            $this->mark_item_as_blocked_gateway($order, $item);
            $this->log_blocked_gateway_transfer($order, $item, $account_number, $sku_code, $send_value, $send_currency_iso);
            return ['success' => false, 'pending_retry' => false, 'message' => 'gateway_not_allowed'];
        }

        $normalized_dispatch_amount = $this->normalize_fixed_send_value_for_dispatch($order, $item, $send_value, $send_currency_iso);
        $send_value = (float) ($normalized_dispatch_amount['send_value'] ?? $send_value);
        $send_currency_iso = (string) ($normalized_dispatch_amount['send_currency_iso'] ?? $send_currency_iso);

        $lock_key = 'dc_transfer_lock_' . md5($order->get_id() . '_' . $item->get_id());
        if (get_transient($lock_key)) {
            $order->add_order_note(sprintf(
                'DingConnect: item #%d omitido temporalmente por lock anti-duplicado activo (60s).',
                (int) $item->get_id()
            ));
            $this->api->log_operational_event('dispatch_locked', [
                'status' => 'pending',
                'order_id' => (int) $order->get_id(),
                'item_id' => (int) $item->get_id(),
                'account_number' => $account_number,
                'sku_code' => $sku_code,
                'send_value' => $send_value,
                'currency' => $send_currency_iso,
            ]);
            return ['success' => false, 'pending_retry' => true, 'message' => 'lock'];
        }
        set_transient($lock_key, 1, 60);

        $attempt = (int) $item->get_meta('_dc_retry_attempts');
        $attempt++;
        call_user_func([$item, 'update_meta_data'], '_dc_retry_attempts', $attempt);
        call_user_func([$item, 'update_meta_data'], '_dc_last_attempt_at', current_time('mysql'));
        call_user_func([$item, 'update_meta_data'], '_dc_transfer_status', 'processing');
        call_user_func([$item, 'save']);

        $order->add_order_note(sprintf(
            'DingConnect: intento #%d para item #%d (telefono: %s, sku: %s).',
            $attempt,
            (int) $item->get_id(),
            $account_number,
            $sku_code
        ));
        $this->api->log_operational_event('dispatch_started', [
            'status' => 'pending',
            'order_id' => (int) $order->get_id(),
            'item_id' => (int) $item->get_id(),
            'account_number' => $account_number,
            'sku_code' => $sku_code,
            'send_value' => $send_value,
            'currency' => $send_currency_iso,
            'raw_response' => ['attempt' => $attempt, 'manual' => (bool) $manual],
        ]);

        // Fase 1: Validación local de monto ANTES de contactar al proveedor.
        // Evita cargos por montos fuera de rango y retroalimentación inmediata al operador.
        $pre_validation = $this->validate_send_value_from_item($item);
        if (is_wp_error($pre_validation)) {
            $val_data    = $pre_validation->get_error_data();
            $val_code    = (string) ($val_data['code'] ?? 'amount_validation_failed');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_status', 'failed_permanent');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error', $pre_validation->get_error_message());
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_code', $val_code);
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_http_status', '400');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_context', 'local_validation');
            call_user_func([$item, 'delete_meta_data'], '_dc_next_retry_at');
            call_user_func([$item, 'save']);

            $order->add_order_note(sprintf(
                'Recarga BLOQUEADA localmente para %s (SKU: %s), intento %d — Monto inválido, no se contactó al proveedor. %s | Valor: %.2f | Código: %s [sin reintento automático]',
                $account_number,
                $sku_code,
                $attempt,
                $pre_validation->get_error_message(),
                $send_value,
                $val_code
            ));
            $this->api->log_operational_event('dispatch_failed_local_validation', [
                'status' => 'error',
                'order_id' => (int) $order->get_id(),
                'item_id' => (int) $item->get_id(),
                'account_number' => $account_number,
                'sku_code' => $sku_code,
                'send_value' => $send_value,
                'currency' => $send_currency_iso,
                'raw_response' => [
                    'attempt' => $attempt,
                    'code' => $val_code,
                    'message' => $pre_validation->get_error_message(),
                ],
            ]);

            delete_transient($lock_key);
            return ['success' => false, 'pending_retry' => false, 'message' => $pre_validation->get_error_message()];
        }

        $distributor_ref = $this->api->new_ref();
        $payload = [
            'DistributorRef' => $distributor_ref,
            'AccountNumber' => $account_number,
            'SkuCode' => $sku_code,
            'SendValue' => $send_value,
            'SendCurrencyIso' => $send_currency_iso,
            'ValidateOnly' => false,
            'Settings' => $settings,
            'BillRef' => $bill_ref,
        ];

        if ($this->api->is_effective_validate_only($payload)) {
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_status', 'validate_only');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error', 'Despacho omitido: el plugin está configurado en modo ValidateOnly y no ejecuta recargas reales.');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_code', 'validate_only_mode');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_context', 'local_policy');
            call_user_func([$item, 'update_meta_data'], '_dc_distributor_ref', $distributor_ref);
            call_user_func([$item, 'delete_meta_data'], '_dc_next_retry_at');
            call_user_func([$item, 'save']);

            $order->add_order_note(sprintf(
                'Recarga OMITIDA para %s (SKU: %s), intento %d: modo ValidateOnly activo. No se envió recarga real a DingConnect.',
                $account_number,
                $sku_code,
                $attempt
            ));
            $this->api->log_operational_event('dispatch_skipped_validate_only', [
                'status' => 'validate',
                'order_id' => (int) $order->get_id(),
                'item_id' => (int) $item->get_id(),
                'account_number' => $account_number,
                'sku_code' => $sku_code,
                'send_value' => $send_value,
                'currency' => $send_currency_iso,
                'distributor_ref' => $distributor_ref,
                'raw_response' => [
                    'attempt' => $attempt,
                    'mode' => 'validate_only',
                ],
            ]);

            delete_transient($lock_key);
            return ['success' => false, 'pending_retry' => false, 'message' => 'validate_only_mode'];
        }

        $response = $this->api->send_transfer($payload);
        $this->api->log_transfer($account_number, $sku_code, $send_value, $send_currency_iso, $distributor_ref, $response);

        if (is_wp_error($response)) {
            $is_non_retryable = $this->is_non_retryable_error($response);
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_status', 'error');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error', $response->get_error_message());
            call_user_func([$item, 'update_meta_data'], '_dc_distributor_ref', $distributor_ref);

            // Fase 1: Enriquecer metadatos con información diagnóstica del error del proveedor
            $error_data          = $response->get_error_data();
            $http_status_code    = isset($error_data['status']) ? (int) $error_data['status'] : 0;
            $ding_error_code     = sanitize_text_field((string) ($error_data['ding_error_code'] ?? ''));
            $ding_error_context  = sanitize_text_field((string) ($error_data['ding_error_context'] ?? ''));
            $error_transfer_ref  = sanitize_text_field((string) ($error_data['transfer_ref'] ?? ''));
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_http_status',    $http_status_code > 0 ? (string) $http_status_code : '');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_code',     $ding_error_code);
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_context',  $ding_error_context);
            if ($error_transfer_ref !== '') {
                call_user_func([$item, 'update_meta_data'], '_dc_transfer_ref', $error_transfer_ref);
            }

            $retry_budget = $this->get_retry_attempt_limit();
            $can_schedule_retry = !$manual && !$is_non_retryable && $attempt <= $retry_budget;

            if ($can_schedule_retry) {
                $retry_ts = time() + (60 * $this->get_retry_delay_minutes($attempt));
                call_user_func([$item, 'update_meta_data'], '_dc_transfer_status', 'pending_retry');
                call_user_func([$item, 'update_meta_data'], '_dc_next_retry_at', gmdate('Y-m-d H:i:s', $retry_ts));
                wp_clear_scheduled_hook('dc_recargas_retry_transfer', [(int) $order->get_id(), (int) $item->get_id()]);
                wp_schedule_single_event($retry_ts, 'dc_recargas_retry_transfer', [(int) $order->get_id(), (int) $item->get_id()]);
            } elseif ($is_non_retryable) {
                call_user_func([$item, 'update_meta_data'], '_dc_transfer_status', 'failed_permanent');
                call_user_func([$item, 'delete_meta_data'], '_dc_next_retry_at');
            }

            call_user_func([$item, 'save']);
            $order->add_order_note(sprintf(
                'Recarga FALLIDA para %s (SKU: %s), intento %d: %s | HTTP=%s | Code=%s | Context=%s | DistRef=%s | TransRef=%s%s',
                $account_number,
                $sku_code,
                $attempt,
                $response->get_error_message(),
                $http_status_code > 0 ? (string) $http_status_code : '-',
                $ding_error_code !== '' ? $ding_error_code : '-',
                $ding_error_context !== '' ? $ding_error_context : '-',
                $distributor_ref,
                $error_transfer_ref !== '' ? $error_transfer_ref : '-',
                $is_non_retryable ? ' [sin reintento automático]' : ''
            ));
            $this->api->log_operational_event('dispatch_result', [
                'status' => $can_schedule_retry ? 'pending_retry' : 'error',
                'order_id' => (int) $order->get_id(),
                'item_id' => (int) $item->get_id(),
                'account_number' => $account_number,
                'sku_code' => $sku_code,
                'send_value' => $send_value,
                'currency' => $send_currency_iso,
                'distributor_ref' => $distributor_ref,
                'transfer_ref' => $error_transfer_ref,
                'raw_response' => [
                    'attempt' => $attempt,
                    'message' => $response->get_error_message(),
                    'http_status' => $http_status_code,
                    'ding_error_code' => $ding_error_code,
                    'ding_error_context' => $ding_error_context,
                    'scheduled_retry' => (bool) $can_schedule_retry,
                ],
            ]);

            delete_transient($lock_key);

            return [
                'success' => false,
                'pending_retry' => $can_schedule_retry,
                'message' => $response->get_error_message(),
            ];
        }

        $snapshot = $this->extract_transfer_snapshot($response, $distributor_ref);
        $applied = $this->apply_transfer_snapshot_to_item($item, $snapshot, $account_number, $send_value);
        $status = $snapshot['status_label'];
        $transfer_ref = $snapshot['transfer_ref'];
        $receive_value = $snapshot['receive_value'];
        $receive_currency = $snapshot['receive_currency'];
        $is_status_success = $this->is_successful_transfer_status($snapshot['status']);
        $has_confirmed_ref = $this->api->is_confirmed_transfer_reference($snapshot['transfer_ref']);
        $is_success = $is_status_success && $has_confirmed_ref;
        $is_pending = $this->is_pending_transfer_status($snapshot['status']) || ($is_status_success && !$has_confirmed_ref);

        if ($is_status_success && !$has_confirmed_ref) {
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_status', 'pending_confirmation');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error', 'Estado exitoso sin referencia de transferencia confirmada. Se requiere conciliación por ListTransferRecords.');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_code', 'missing_confirmed_transfer_ref');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_context', 'post_dispatch_validation');
            call_user_func([$item, 'save']);
        }

        if ($is_pending && !$manual) {
            $this->schedule_submitted_retry($order, $item, 'send_transfer_pending');
        }

        if ($is_success) {
            $note = sprintf(
                'Recarga EXITOSA para %s (SKU: %s), intento %d - Ref: %s - Estado: %s',
                $account_number,
                $sku_code,
                $attempt,
                $transfer_ref,
                $status
            );
        } elseif ($is_pending) {
            $note = sprintf(
                'Recarga enviada a DingConnect para conciliacion posterior para %s (SKU: %s), intento %d - Ref: %s - Estado: %s',
                $account_number,
                $sku_code,
                $attempt,
                $transfer_ref !== '' ? $transfer_ref : $distributor_ref,
                $status
            );
        } else {
            $note = sprintf(
                'Recarga registrada con estado no terminal para %s (SKU: %s), intento %d - Ref: %s - Estado: %s',
                $account_number,
                $sku_code,
                $attempt,
                $transfer_ref !== '' ? $transfer_ref : $distributor_ref,
                $status
            );
        }

        if ($receive_value > 0) {
            $note .= sprintf(' - Recibe: %s %s', $receive_currency, $receive_value);
        }

        $order->add_order_note($note);
        $this->api->log_operational_event('dispatch_result', [
            'status' => $is_success ? 'TransferSuccessful' : ($is_pending ? 'pending' : 'unknown'),
            'order_id' => (int) $order->get_id(),
            'item_id' => (int) $item->get_id(),
            'account_number' => $account_number,
            'sku_code' => $sku_code,
            'send_value' => $send_value,
            'currency' => $send_currency_iso,
            'distributor_ref' => $distributor_ref,
            'transfer_ref' => $transfer_ref,
            'raw_response' => [
                'attempt' => $attempt,
                'status' => $snapshot['status'] ?? '',
                'status_label' => $status,
                'receive_value' => $receive_value,
                'receive_currency' => $receive_currency,
            ],
        ]);

        // Enviar email de confirmación al cliente cuando la recarga es exitosa
        if ($is_success && $applied) {
            $this->send_recarga_confirmacion_email($order, $item, $snapshot);
        }

        delete_transient($lock_key);

        return ['success' => $is_success, 'pending_retry' => $is_pending, 'status' => $snapshot['status']];
    }

    private function sync_item_with_ding_status($order, $item) {
        $transfer_ref = (string) $item->get_meta('_dc_transfer_ref');
        $distributor_ref = (string) $item->get_meta('_dc_distributor_ref');
        $account_number = (string) $item->get_meta('_dc_account_number');

        if ($transfer_ref === '' && $distributor_ref === '') {
            return ['synced' => false, 'success' => false, 'pending' => false];
        }

        $response = $this->api->list_transfer_records([
            'TransferRef' => $transfer_ref,
            'DistributorRef' => $distributor_ref,
            'AccountNumber' => $account_number,
            'Take' => 1,
        ]);

        if (is_wp_error($response)) {
            $order->add_order_note(sprintf(
                'DingConnect: no se pudo reconciliar estado para item #%d (%s). Motivo: %s',
                (int) $item->get_id(),
                $account_number,
                $response->get_error_message()
            ));
            return ['synced' => false, 'success' => false, 'pending' => false];
        }

        $items = $response['Result'] ?? $response['Items'] ?? [];
        if (empty($items[0]) || !is_array($items[0])) {
            $order->add_order_note(sprintf(
                'DingConnect: reconciliacion sin registros para item #%d (%s). Se mantiene estado local.',
                (int) $item->get_id(),
                $account_number
            ));
            return ['synced' => false, 'success' => false, 'pending' => false];
        }

        $previous_status = strtolower((string) $item->get_meta('_dc_transfer_status'));
        $snapshot = $this->extract_transfer_snapshot($items[0], $distributor_ref);
        if ($snapshot['status'] === '') {
            return ['synced' => false, 'success' => false, 'pending' => false];
        }

        $send_value = (float) $item->get_meta('_dc_send_value');
        $applied = $this->apply_transfer_snapshot_to_item($item, $snapshot, $account_number, $send_value);

        $is_status_success = $this->is_successful_transfer_status($snapshot['status']);
        $has_confirmed_ref = $this->api->is_confirmed_transfer_reference($snapshot['transfer_ref']);
        $is_now_success = $is_status_success && $has_confirmed_ref;
        $is_now_pending = $this->is_pending_transfer_status($snapshot['status']) || ($is_status_success && !$has_confirmed_ref);

        if ($is_status_success && !$has_confirmed_ref) {
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_status', 'pending_confirmation');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error', 'Estado exitoso sin referencia de transferencia confirmada. Se requiere conciliación por ListTransferRecords.');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_code', 'missing_confirmed_transfer_ref');
            call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_context', 'sync_validation');
            call_user_func([$item, 'save']);
        }

        if ($snapshot['status'] !== $previous_status || $applied) {
            $order->add_order_note(sprintf(
                'Reconciliacion DingConnect para %s (SKU: %s): estado %s.',
                $account_number,
                (string) $item->get_meta('_dc_sku_code'),
                $snapshot['status_label'] !== '' ? $snapshot['status_label'] : strtoupper($snapshot['status'])
            ));

            // Enviar email de confirmación cuando la reconciliación transiciona a éxito
            if ($is_now_success && $applied) {
                $this->send_recarga_confirmacion_email($order, $item, $snapshot);
            }
        }

        return [
            'synced' => true,
            'success' => $is_now_success,
            'pending' => $is_now_pending,
            'status' => $snapshot['status'],
        ];
    }

    private function sync_order_status_with_recarga_outcome($order, $context = '') {
        if (!$order instanceof WC_Order) {
            return;
        }

        $summary = $this->build_recarga_status_summary($order);
        if ($summary['total'] < 1) {
            return;
        }

        $current_status = $this->get_order_status_slug($order);
        $blocked_statuses = ['cancelled', 'refunded', 'failed'];
        if (in_array($current_status, $blocked_statuses, true)) {
            $order->add_order_note(sprintf(
                'DingConnect: politica de estado omitida porque la orden esta en %s. Resumen recargas: %s',
                strtoupper($current_status),
                $this->format_recarga_summary_text($summary)
            ));
            return;
        }

        $target_status = 'processing';
        $decision = 'Pago confirmado y recarga en curso/pending.';

        if ($summary['success'] === $summary['total']) {
            $target_status = 'completed';
            $decision = 'Todas las recargas DingConnect quedaron confirmadas como exitosas.';
        } elseif ($summary['error'] > 0) {
            $target_status = 'on-hold';
            $decision = 'Existen recargas con error definitivo o escaladas a soporte.';
        }

        $reason = sprintf(
            'DingConnect policy (%s): %s Resumen: %s',
            $context !== '' ? $context : 'runtime',
            $decision,
            $this->format_recarga_summary_text($summary)
        );

        call_user_func([$order, 'update_meta_data'], '_dc_recargas_status_summary', wp_json_encode($summary));
        call_user_func([$order, 'update_meta_data'], '_dc_recargas_status_context', sanitize_text_field((string) $context));
        call_user_func([$order, 'update_meta_data'], '_dc_recargas_status_synced_at', current_time('mysql'));

        if ($current_status !== $target_status) {
            $this->update_order_status_slug($order, $target_status, $reason);
            return;
        }

        $order->add_order_note($reason);
    }

    private function force_sync_order_status_on_thankyou($order) {
        if (!$order instanceof WC_Order) {
            return false;
        }

        $blocked_statuses = ['cancelled', 'refunded', 'failed'];
        $current_status = $this->get_order_status_slug($order);
        if (in_array($current_status, $blocked_statuses, true)) {
            return false;
        }

        $synced = false;
        foreach ($order->get_items() as $item) {
            if ($item->get_meta('_dc_recarga') !== 'yes') {
                continue;
            }

            $transfer_ref = (string) $item->get_meta('_dc_transfer_ref');
            $item_status = strtolower((string) $item->get_meta('_dc_transfer_status'));

            if ($this->is_successful_transfer_status($item_status) && $this->api->is_confirmed_transfer_reference($transfer_ref)) {
                continue;
            }

            if ($transfer_ref === '' && $item_status === '') {
                continue;
            }

            $sync_result = $this->sync_item_with_ding_status($order, $item);
            if (!empty($sync_result['synced'])) {
                $synced = true;
            }
        }

        if ($synced) {
            call_user_func([$order, 'save']);
        }

        $this->sync_order_status_with_recarga_outcome($order, 'thankyou_safety_net');
        call_user_func([$order, 'save']);

        return true;
    }

    private function build_recarga_status_summary($order) {
        $summary = [
            'total' => 0,
            'success' => 0,
            'pending' => 0,
            'error' => 0,
            'status_map' => [],
        ];

        foreach ($order->get_items() as $item) {
            if ($item->get_meta('_dc_recarga') !== 'yes') {
                continue;
            }

            $summary['total']++;
            $status = strtolower(trim((string) $item->get_meta('_dc_transfer_status')));

            if ($status === '') {
                $status = 'not_started';
            }

            if (!isset($summary['status_map'][$status])) {
                $summary['status_map'][$status] = 0;
            }
            $summary['status_map'][$status]++;

            if ($this->is_successful_transfer_status($status)) {
                $summary['success']++;
                continue;
            }

            if ($this->is_pending_order_level_status($status)) {
                $summary['pending']++;
                continue;
            }

            $summary['error']++;
        }

        ksort($summary['status_map']);

        return $summary;
    }

    private function is_pending_order_level_status($status) {
        if ($this->is_pending_transfer_status($status)) {
            return true;
        }

        return in_array(strtolower((string) $status), ['pending_retry', 'not_started'], true);
    }

    private function format_recarga_summary_text(array $summary) {
        $parts = [
            sprintf('total=%d', (int) ($summary['total'] ?? 0)),
            sprintf('success=%d', (int) ($summary['success'] ?? 0)),
            sprintf('pending=%d', (int) ($summary['pending'] ?? 0)),
            sprintf('error=%d', (int) ($summary['error'] ?? 0)),
        ];

        $status_map = (array) ($summary['status_map'] ?? []);
        if (!empty($status_map)) {
            $status_parts = [];
            foreach ($status_map as $status => $count) {
                $status_parts[] = sprintf('%s:%d', (string) $status, (int) $count);
            }

            $parts[] = 'states=[' . implode(', ', $status_parts) . ']';
        }

        return implode(' | ', $parts);
    }

    private function get_order_status_slug($order) {
        if (!($order instanceof WC_Order)) {
            return '';
        }

        $status = get_post_status((int) $order->get_id());
        if (!is_string($status)) {
            return '';
        }

        return strpos($status, 'wc-') === 0 ? substr($status, 3) : $status;
    }

    private function get_dispatch_stage_for_order($order) {
        $options = $this->api->get_options();
        $fallback = $this->sanitize_dispatch_stage((string) ($options['woo_dispatch_stage_default'] ?? 'payment_complete'));
        $map = (array) ($options['woo_dispatch_stage_by_gateway'] ?? []);
        $payment_method = sanitize_key((string) ($order instanceof WC_Order ? call_user_func([$order, 'get_payment_method']) : ''));
        if ($payment_method === '') {
            return $fallback;
        }

        $by_gateway = sanitize_key((string) ($map[$payment_method] ?? ''));
        if ($by_gateway === '') {
            return $fallback;
        }

        return $this->sanitize_dispatch_stage($by_gateway);
    }

    private function should_process_order_for_trigger_stage($order, $trigger_stage) {
        $selected_stage = $this->get_dispatch_stage_for_order($order);
        $trigger_stage = $this->sanitize_dispatch_stage((string) $trigger_stage);
        return $selected_stage === $trigger_stage;
    }

    private function sanitize_dispatch_stage($stage) {
        $stage = sanitize_key((string) $stage);
        $allowed = ['payment_complete', 'processing', 'completed'];
        if (!in_array($stage, $allowed, true)) {
            return 'payment_complete';
        }
        return $stage;
    }

    private function update_order_status_slug($order, $target_status, $reason = '') {
        if (!($order instanceof WC_Order)) {
            return false;
        }

        $target_status = sanitize_key((string) $target_status);
        if ($target_status === '') {
            return false;
        }

        $updated = call_user_func('wp_update_post', [
            'ID' => (int) $order->get_id(),
            'post_status' => 'wc-' . $target_status,
        ], true);

        if (is_wp_error($updated)) {
            $order->add_order_note(sprintf(
                'DingConnect: no se pudo actualizar estado de orden a %s. Motivo: %s',
                strtoupper($target_status),
                $updated->get_error_message()
            ));
            return false;
        }

        if ($reason !== '') {
            $order->add_order_note($reason);
        }

        return true;
    }

    private function extract_transfer_snapshot($payload, $fallback_distributor_ref = '') {
        return $this->api->extract_transfer_snapshot($payload, $fallback_distributor_ref);
    }

    private function apply_transfer_snapshot_to_item($item, $snapshot, $account_number, $send_value) {
        $order = $item->get_order();
        if ($order) {
            $lock = 'dc_voucher_lock_' . md5($order->get_id() . ':' . $item->get_id());
            if (get_transient($lock)) { 
                return false; 
            }
            set_transient($lock, 1, 60);
            try {
                $voucher_v2 = $this->voucher_service->build_snapshot($order, $item, $snapshot);
                $new_hash = (string) $voucher_v2['voucher_hash'];
                
                if ((string) $item->get_meta('_dc_voucher_hash') === $new_hash) {
                    return false; // ya generado para mismo estado/snapshot
                }
                
                $this->api->log_operational_event('voucher_generated', [
                    'order_id' => $order->get_id(),
                    'item_id' => $item->get_id(),
                    'voucher_hash' => $new_hash
                ]);
                
                $this->api->apply_transfer_snapshot_to_item($item, $snapshot, $account_number, $send_value);
                
                $snapshot_safe = is_array($snapshot) ? $snapshot : [];
                $voucher_payload = [
                    'transaction_id' => $snapshot_safe['transfer_ref'] ?? '',
                    'status' => $snapshot_safe['status_label'] ?? '',
                    'operator' => (string) $item->get_meta('_dc_provider_name'),
                    'flow_kind' => (string) $item->get_meta('_dc_flow_kind'),
                    'product_type' => (string) $item->get_meta('_dc_product_type'),
                    'amount_sent' => $send_value,
                    'amount_received' => (float) ($snapshot_safe['receive_value'] ?? 0),
                    'beneficiary_phone' => $account_number,
                    'timestamp' => current_time('mysql'),
                    'promotion' => '',
                    'receipt_text' => (string) ($snapshot_safe['receipt_text'] ?? ''),
                    'receipt_params' => (array) ($snapshot_safe['receipt_params'] ?? []),
                    'processing_state' => (string) ($snapshot_safe['processing_state'] ?? ''),
                    'bill_ref' => (string) $item->get_meta('_dc_bill_ref'),
                    'customer_care_number' => (string) $item->get_meta('_dc_customer_care_number'),
                ];
                
                call_user_func([$item, 'update_meta_data'], '_dc_voucher_payload', wp_json_encode($voucher_payload));
                call_user_func([$item, 'update_meta_data'], '_dc_voucher_payload_v2', wp_json_encode($voucher_v2));
                call_user_func([$item, 'update_meta_data'], '_dc_voucher_hash', $new_hash);
                call_user_func([$item, 'save']);
                
                return true;
            } finally {
                delete_transient($lock);
            }
        }
        
        return false;
    }

    private function is_successful_transfer_status($status) {
        return $this->api->is_successful_transfer_status($status);
    }

    private function is_pending_transfer_status($status) {
        return $this->api->is_pending_transfer_status($status);
    }

    public function handle_dingconnect_webhook($payload, $context = []) {
        $payload = is_array($payload) ? $payload : [];
        $context = is_array($context) ? $context : [];

        $refs = $this->extract_refs_from_webhook_payload($payload);
        $transfer_ref = $refs['transfer_ref'];
        $distributor_ref = $refs['distributor_ref'];
        $account_number = $refs['account_number'];

        $matches = $this->find_order_items_by_dc_refs($transfer_ref, $distributor_ref);
        $processed = 0;
        $updated = 0;
        $emailed = 0;
        $synced_order_ids = [];

        foreach ($matches as $match) {
            $order_id = (int) ($match['order_id'] ?? 0);
            $item_id = (int) ($match['order_item_id'] ?? 0);
            if ($order_id < 1 || $item_id < 1) {
                continue;
            }

            $order = function_exists('wc_get_order') ? wc_get_order($order_id) : null;
            if (!($order instanceof WC_Order)) {
                continue;
            }

            $item = $order->get_item($item_id);
            if (!($item instanceof WC_Order_Item_Product)) {
                continue;
            }

            $previous_status = strtolower((string) $item->get_meta('_dc_transfer_status'));
            $item_account_number = (string) $item->get_meta('_dc_account_number');
            $effective_account_number = $account_number !== '' ? $account_number : $item_account_number;
            $send_value = (float) $item->get_meta('_dc_send_value');

            $snapshot = $this->extract_transfer_snapshot($payload, $distributor_ref);
            if (($snapshot['status'] ?? '') === '') {
                $response = $this->api->list_transfer_records([
                    'TransferRef' => $transfer_ref,
                    'DistributorRef' => $distributor_ref,
                    'AccountNumber' => $effective_account_number,
                    'Take' => 1,
                ]);

                if (!is_wp_error($response)) {
                    $items = $response['Result'] ?? $response['Items'] ?? [];
                    if (!empty($items[0]) && is_array($items[0])) {
                        $snapshot = $this->extract_transfer_snapshot($items[0], $distributor_ref);
                    }
                }
            }

            if (($snapshot['status'] ?? '') === '') {
                $processed++;
                continue;
            }

            $applied = $this->apply_transfer_snapshot_to_item($item, $snapshot, $effective_account_number, $send_value);

            $is_now_success = $this->is_successful_transfer_status($snapshot['status']);
            if (($snapshot['status'] ?? '') !== $previous_status || $applied) {
                $order->add_order_note(sprintf(
                    'DingConnect webhook para %s (SKU: %s): estado %s.',
                    $effective_account_number,
                    (string) $item->get_meta('_dc_sku_code'),
                    ($snapshot['status_label'] ?? '') !== '' ? (string) $snapshot['status_label'] : strtoupper((string) ($snapshot['status'] ?? ''))
                ));
                $updated++;

                if ($is_now_success && $applied) {
                    $this->send_recarga_confirmacion_email($order, $item, $snapshot);
                    $emailed++;
                }
            }

            call_user_func([$order, 'save']);
            $processed++;

            if (!in_array($order_id, $synced_order_ids, true)) {
                $synced_order_ids[] = $order_id;
            }
        }

        foreach ($synced_order_ids as $order_id) {
            $order = wc_get_order($order_id);
            if ($order instanceof WC_Order) {
                $this->sync_order_status_with_recarga_outcome($order, 'webhook');
                call_user_func([$order, 'save']);
            }
        }

        if (empty($matches)) {
            $log_account = $account_number !== '' ? $account_number : 'unknown';
            $log_sku = $refs['sku_code'] !== '' ? $refs['sku_code'] : 'webhook';
            $log_ref = $distributor_ref !== '' ? $distributor_ref : ($transfer_ref !== '' ? $transfer_ref : ('webhook-' . md5(wp_json_encode($payload))));
            $this->api->log_transfer($log_account, $log_sku, 0, '', $log_ref, $payload);
        }

        return [
            'matched' => count($matches),
            'processed' => $processed,
            'updated' => $updated,
            'emailed' => $emailed,
            'transfer_ref' => $transfer_ref,
            'distributor_ref' => $distributor_ref,
        ];
    }

    private function extract_refs_from_webhook_payload($payload) {
        $payload = is_array($payload) ? $payload : [];
        $record = is_array($payload['TransferRecord'] ?? null) ? $payload['TransferRecord'] : $payload;
        $transfer_id = is_array($record['TransferId'] ?? null) ? $record['TransferId'] : [];

        $transfer_ref = sanitize_text_field((string) ($transfer_id['TransferRef'] ?? $payload['TransferRef'] ?? $payload['transfer_ref'] ?? ''));
        $distributor_ref = sanitize_text_field((string) ($transfer_id['DistributorRef'] ?? $payload['DistributorRef'] ?? $payload['distributor_ref'] ?? ''));
        $account_number = sanitize_text_field((string) ($record['AccountNumber'] ?? $payload['AccountNumber'] ?? $payload['account_number'] ?? ''));
        $sku_code = sanitize_text_field((string) ($record['SkuCode'] ?? $payload['SkuCode'] ?? $payload['sku_code'] ?? ''));

        return [
            'transfer_ref' => $transfer_ref,
            'distributor_ref' => $distributor_ref,
            'account_number' => $account_number,
            'sku_code' => $sku_code,
        ];
    }

    private function find_order_items_by_dc_refs($transfer_ref, $distributor_ref) {
        $transfer_ref = sanitize_text_field((string) $transfer_ref);
        $distributor_ref = sanitize_text_field((string) $distributor_ref);

        $conditions = [];
        $params = [];

        if ($transfer_ref !== '') {
            $conditions[] = "(oim.meta_key = '_dc_transfer_ref' AND oim.meta_value = %s)";
            $params[] = $transfer_ref;
        }
        if ($distributor_ref !== '') {
            $conditions[] = "(oim.meta_key = '_dc_distributor_ref' AND oim.meta_value = %s)";
            $params[] = $distributor_ref;
        }

        if (empty($conditions)) {
            return [];
        }

        global $wpdb;
        $order_items = $wpdb->prefix . 'woocommerce_order_items';
        $order_itemmeta = $wpdb->prefix . 'woocommerce_order_itemmeta';

        $sql = "SELECT DISTINCT oi.order_id, oi.order_item_id
            FROM {$order_items} oi
            INNER JOIN {$order_itemmeta} oim ON oi.order_item_id = oim.order_item_id
            WHERE oi.order_item_type = 'line_item'
              AND (" . implode(' OR ', $conditions) . ')';

        $prepared = $wpdb->prepare($sql, $params);
        $rows = $wpdb->get_results($prepared, 'ARRAY_A');

        $normalized = [];
        foreach ((array) $rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $order_id = (int) ($row['order_id'] ?? 0);
            $item_id = (int) ($row['order_item_id'] ?? 0);
            if ($order_id > 0 && $item_id > 0) {
                $normalized[] = [
                    'order_id' => $order_id,
                    'order_item_id' => $item_id,
                ];
            }
        }

        return $normalized;
    }

    private function get_retry_attempt_limit() {
        $options = $this->api->get_options();
        $attempts = (int) ($options['submitted_retry_max_attempts'] ?? 4);

        if ($attempts < 1) {
            $attempts = 1;
        }
        if ($attempts > 8) {
            $attempts = 8;
        }

        return $attempts;
    }

    private function get_retry_delay_minutes($attempt = 1) {
        $attempt = max(1, (int) $attempt);
        $schedule = $this->get_retry_backoff_schedule();
        $index = min($attempt - 1, count($schedule) - 1);

        return (int) $schedule[$index];
    }

    private function get_retry_backoff_schedule() {
        $options = $this->api->get_options();
        $raw = (string) ($options['submitted_retry_backoff_minutes'] ?? '10,20,40,80');
        $parts = preg_split('/[\s,;]+/', $raw);
        $minutes = [];

        foreach ((array) $parts as $part) {
            $value = (int) $part;
            if ($value < 1 || $value > 720) {
                continue;
            }
            $minutes[] = $value;
        }

        $minutes = array_values(array_unique($minutes));
        if (empty($minutes)) {
            $minutes = [10, 20, 40, 80];
        }

        return $minutes;
    }

    private function get_submitted_max_window_hours() {
        $options = $this->api->get_options();
        $hours = (int) ($options['submitted_max_window_hours'] ?? 12);
        if ($hours < 1) {
            $hours = 1;
        }
        if ($hours > 168) {
            $hours = 168;
        }

        return $hours;
    }

    private function get_non_retryable_error_codes() {
        $options = $this->api->get_options();
        $raw = (string) ($options['submitted_non_retryable_codes'] ?? 'InsufficientBalance,AccountNumberInvalid,RechargeNotAllowed');
        $parts = preg_split('/[\s,;]+/', $raw);
        $codes = [];

        foreach ((array) $parts as $part) {
            $clean = preg_replace('/[^A-Za-z0-9_]/', '', (string) $part);
            if ($clean !== '') {
                $codes[] = strtolower($clean);
            }
        }

        return array_values(array_unique($codes));
    }

    private function is_non_retryable_error($error) {
        if (!$error instanceof WP_Error) {
            return false;
        }

        $data = $error->get_error_data();
        $code = strtolower((string) ($data['ding_error_code'] ?? ''));
        if ($code === '') {
            return false;
        }

        return in_array($code, $this->get_non_retryable_error_codes(), true);
    }

    private function schedule_submitted_retry($order, $item, $reason = '') {
        if (!($order instanceof WC_Order) || !($item instanceof WC_Order_Item_Product)) {
            return false;
        }

        /** @var WC_Order_Item_Product $item */

        $status = strtolower((string) $item->get_meta('_dc_transfer_status'));
        if (!$this->is_pending_transfer_status($status) && $status !== 'pending_retry') {
            return false;
        }

        $submitted_since = (string) $item->get_meta('_dc_submitted_since');
        if ($submitted_since === '') {
            $submitted_since = current_time('mysql');
            call_user_func([$item, 'update_meta_data'], '_dc_submitted_since', $submitted_since);
        }

        $submitted_ts = strtotime($submitted_since);
        $max_window_seconds = $this->get_submitted_max_window_hours() * HOUR_IN_SECONDS;
        if ($submitted_ts && (time() - $submitted_ts) >= $max_window_seconds) {
            $this->escalate_submitted_item($order, $item, 'timeout_window');
            return false;
        }

        $attempt = (int) $item->get_meta('_dc_submitted_retry_attempts');
        $attempt++;
        call_user_func([$item, 'update_meta_data'], '_dc_submitted_retry_attempts', $attempt);

        if ($attempt > $this->get_retry_attempt_limit()) {
            $this->escalate_submitted_item($order, $item, 'attempt_limit');
            return false;
        }

        $delay_minutes = $this->get_retry_delay_minutes($attempt);
        $retry_ts = time() + ($delay_minutes * MINUTE_IN_SECONDS);

        call_user_func([$item, 'update_meta_data'], '_dc_transfer_status', 'pending_retry');
        call_user_func([$item, 'update_meta_data'], '_dc_next_retry_at', gmdate('Y-m-d H:i:s', $retry_ts));
        call_user_func([$item, 'save']);

        $item_id = (int) call_user_func([$item, 'get_id']);

        wp_clear_scheduled_hook('dc_recargas_retry_transfer', [(int) $order->get_id(), $item_id]);
        wp_schedule_single_event($retry_ts, 'dc_recargas_retry_transfer', [(int) $order->get_id(), $item_id]);

        $order->add_order_note(sprintf(
            'Recarga en estado pendiente (razón: %s). Reintento %d/%d en %d min para item %d.',
            $reason !== '' ? $reason : 'status_pending',
            $attempt,
            $this->get_retry_attempt_limit(),
            $delay_minutes,
            $item_id
        ));
        $this->api->log_operational_event('retry_scheduled', [
            'status' => 'pending_retry',
            'order_id' => (int) $order->get_id(),
            'item_id' => $item_id,
            'account_number' => (string) $item->get_meta('_dc_account_number'),
            'sku_code' => (string) $item->get_meta('_dc_sku_code'),
            'send_value' => (float) $item->get_meta('_dc_send_value'),
            'currency' => (string) $item->get_meta('_dc_send_currency_iso'),
            'raw_response' => [
                'reason' => (string) $reason,
                'attempt' => $attempt,
                'delay_minutes' => $delay_minutes,
            ],
        ]);

        return true;
    }

    private function escalate_submitted_item($order, $item, $reason = '') {
        call_user_func([$item, 'update_meta_data'], '_dc_transfer_status', 'escalado_soporte');
        call_user_func([$item, 'delete_meta_data'], '_dc_next_retry_at');
        call_user_func([$item, 'save']);

        wp_clear_scheduled_hook('dc_recargas_retry_transfer', [(int) $order->get_id(), (int) $item->get_id()]);

        $phone = (string) $item->get_meta('_dc_account_number');
        $sku = (string) $item->get_meta('_dc_sku_code');
        $since = (string) $item->get_meta('_dc_submitted_since');
        $note = sprintf(
            'ESCALADO SOPORTE: recarga pendiente prolongada para %s (SKU: %s). Motivo: %s. Desde: %s.',
            $phone,
            $sku,
            $reason !== '' ? $reason : 'submitted_prolongado',
            $since !== '' ? $since : 'N/A'
        );

        $order->add_order_note($note);

        $options = $this->api->get_options();
        $escalation_email = sanitize_email((string) ($options['submitted_escalation_email'] ?? ''));
        if ($escalation_email !== '' && function_exists('wp_mail')) {
            call_user_func('wp_mail',
                $escalation_email,
                sprintf('DingConnect escalado: Orden #%d', (int) $order->get_id()),
                $note
            );
        }
    }

    private function infer_flow_kind($product_type, $redemption_mechanism, $lookup_bills_required, $is_range, $bundle_label = '', $receipt_params = []) {
        $product_type = strtolower((string) $product_type);
        $redemption_mechanism = strtolower((string) $redemption_mechanism);
        $bundle_label = strtolower((string) $bundle_label);

        if (!empty($receipt_params['pin']) || $redemption_mechanism === 'readreceipt' || preg_match('/voucher|pin|gift|digital/', $product_type)) {
            return 'voucher';
        }

        if ($lookup_bills_required || preg_match('/electric|bill|utility|power/', $product_type)) {
            return 'electricity';
        }

        if (preg_match('/dth|satellite|tv|dish/', $product_type . ' ' . $bundle_label)) {
            return 'dth';
        }

        if ($is_range) {
            return 'range';
        }

        return 'mobile';
    }

    private function get_item_voucher_payload($item) {
        $payload = json_decode((string) $item->get_meta('_dc_voucher_payload'), true);
        if (!is_array($payload)) {
            $payload = [];
        }

        if (!isset($payload['flow_kind']) || $payload['flow_kind'] === '') {
            $payload['flow_kind'] = (string) $item->get_meta('_dc_flow_kind');
        }

        if ($payload['flow_kind'] === '') {
            $payload['flow_kind'] = $this->infer_flow_kind(
                (string) $item->get_meta('_dc_product_type'),
                (string) $item->get_meta('_dc_redemption_mechanism'),
                (string) $item->get_meta('_dc_lookup_bills_required') === 'yes',
                (string) $item->get_meta('_dc_is_range') === 'yes',
                (string) $item->get_meta('_dc_bundle_label'),
                is_array($payload['receipt_params'] ?? null) ? $payload['receipt_params'] : []
            );
        }

        if (!isset($payload['bill_ref']) || $payload['bill_ref'] === '') {
            $payload['bill_ref'] = (string) $item->get_meta('_dc_bill_ref');
        }

        return $payload;
    }

    private function get_item_copy_title($flow_kind, $status) {
        $status = strtolower(trim((string) $status));
        $state_key = 'error';
        if ($this->is_successful_transfer_status($status)) {
            $state_key = 'success';
        } elseif ($this->is_pending_transfer_status($status) || in_array($status, ['pending_retry', 'escalado_soporte', 'not_started', ''], true)) {
            $state_key = 'pending';
        }

        $titles = [
            'voucher' => [
                'success' => 'Voucher listo para usar',
                'pending' => 'Voucher en validacion',
                'error' => 'Voucher no confirmado',
            ],
            'electricity' => [
                'success' => 'Pago del servicio registrado',
                'pending' => 'Pago del servicio en validacion',
                'error' => 'Pago del servicio no confirmado',
            ],
            'dth' => [
                'success' => 'Recarga DTH registrada',
                'pending' => 'Recarga DTH en validacion',
                'error' => 'Recarga DTH no confirmada',
            ],
            'range' => [
                'success' => 'Recarga movil confirmada',
                'pending' => 'Recarga movil en validacion',
                'error' => 'Recarga movil no confirmada',
            ],
            'mobile' => [
                'success' => 'Recarga procesada',
                'pending' => 'Recarga en validacion',
                'error' => 'Recarga no confirmada',
            ],
        ];

        $flow_titles = $titles[$flow_kind] ?? $titles['mobile'];
        return $flow_titles[$state_key] ?? $flow_titles['pending'];
    }

    private function get_item_receipt_param($payload, $expected_key) {
        $expected_key = strtolower((string) $expected_key);
        $receipt_params = is_array($payload['receipt_params'] ?? null) ? $payload['receipt_params'] : [];

        foreach ($receipt_params as $key => $value) {
            if (strtolower((string) $key) === $expected_key) {
                return sanitize_text_field((string) $value);
            }
        }

        return '';
    }

    public function filter_customer_order_actions($actions, $order) {
        if (!is_array($actions) || empty($actions) || !($order instanceof WC_Order)) {
            return $actions;
        }

        if (!$order->is_paid()) {
            return $actions;
        }

        if (!$this->order_has_recargas($order)) {
            return $actions;
        }

        return [];
    }

    public function filter_my_account_orders_actions($actions, $order) {
        if (!is_array($actions) || empty($actions) || !($order instanceof WC_Order)) {
            return $actions;
        }

        if (!$order->is_paid()) {
            return $actions;
        }

        if (!$this->order_has_recargas($order)) {
            return $actions;
        }

        return [];
    }

    private function order_has_recargas($order) {
        if (!($order instanceof WC_Order)) {
            return false;
        }

        foreach ($order->get_items() as $item) {
            if (!($item instanceof WC_Order_Item_Product)) {
                continue;
            }

            if ($item->get_meta('_dc_recarga') === 'yes') {
                return true;
            }
        }

        return false;
    }

    private function order_has_pending_recargas($order) {
        foreach ($order->get_items() as $item) {
            if ($item->get_meta('_dc_recarga') !== 'yes') {
                continue;
            }

            $status = strtolower((string) $item->get_meta('_dc_transfer_status'));
            if ($this->is_pending_transfer_status($status) || in_array($status, ['pending_retry', 'escalado_soporte'], true)) {
                return true;
            }
        }

        return false;
    }

    private function order_has_error_recargas($order) {
        $summary = $this->build_recarga_status_summary($order);
        return ((int) ($summary['error'] ?? 0)) > 0;
    }

    private function collect_order_voucher_rows($order) {
        $rows = [];

        foreach ($order->get_items() as $item) {
            if ($item->get_meta('_dc_recarga') !== 'yes') {
                continue;
            }

            $phone = (string) $item->get_meta('_dc_account_number');
            $status = strtoupper((string) $item->get_meta('_dc_transfer_status'));
            $ref = (string) $item->get_meta('_dc_transfer_ref');
            $provider = (string) $item->get_meta('_dc_provider_name');
            $public_amount = (float) $item->get_meta('_dc_public_price');
            $public_currency = (string) $item->get_meta('_dc_public_currency_iso');
            $send_amount = (float) $item->get_meta('_dc_send_value');
            $send_currency = (string) $item->get_meta('_dc_send_currency_iso');
            $payload = $this->get_item_voucher_payload($item);
            $flow_kind = (string) ($payload['flow_kind'] ?? 'mobile');
            $pin = $this->get_item_receipt_param($payload, 'pin');
            $provider_ref = $this->get_item_receipt_param($payload, 'providerRef');
            $bill_ref = sanitize_text_field((string) ($payload['bill_ref'] ?? ''));
            $title = $this->get_item_copy_title($flow_kind, strtolower($status));
            $display_status = $status !== '' ? $status : 'PROCESANDO';
            $parts = [
                $title . ': ' . trim($provider . ' ' . $phone),
                (string) $item->get_meta('_dc_bundle_label'),
                $display_status,
                sprintf('Precio %s %.2f', $public_currency !== '' ? $public_currency : $send_currency, $public_amount > 0 ? $public_amount : $send_amount),
            ];

            if ($bill_ref !== '') {
                $parts[] = 'Factura ' . $bill_ref;
            }

            if ($pin !== '') {
                $parts[] = 'PIN ' . $pin;
            }

            if ($provider_ref !== '') {
                $parts[] = 'Ref prov. ' . $provider_ref;
            }

            $parts[] = 'Ref ' . ($ref !== '' ? $ref : 'N/A');

            if (in_array(strtolower($status), ['submitted', 'pending', 'processing', 'pending_retry', 'escalado_soporte'], true)) {
                $parts[] = 'No repetir compra';
            }

            $rows[] = implode(' | ', array_filter($parts, static function ($part) {
                return $part !== '';
            }));
        }

        return $rows;
    }

    private function sanitize_phone($phone) {
        $raw = preg_replace('/[^\d+]/', '', (string) $phone);
        if (strpos($raw, '+') !== 0) {
            $raw = '+' . ltrim($raw, '+');
        }
        return $raw;
    }

    private function get_allowed_gateway_ids_for_recargas() {
        $options = $this->api->get_options();
        $payment_mode = sanitize_key((string) ($options['payment_mode'] ?? 'direct'));
        if ($payment_mode !== 'woocommerce') {
            return [];
        }

        return array_values(array_unique(array_filter(array_map('sanitize_key', (array) ($options['woo_allowed_gateways'] ?? [])))));
    }

    private function is_order_payment_method_allowed_for_recargas($order) {
        if (!($order instanceof WC_Order)) {
            return false;
        }

        $allowed = $this->get_allowed_gateway_ids_for_recargas();
        if (empty($allowed)) {
            return true;
        }

        $payment_method = sanitize_key((string) call_user_func([$order, 'get_payment_method']));
        if ($payment_method === '') {
            return false;
        }

        return in_array($payment_method, $allowed, true);
    }

    private function mark_item_as_blocked_gateway($order, $item) {
        if (!($order instanceof WC_Order) || !($item instanceof WC_Order_Item_Product)) {
            return;
        }

        $payment_method = sanitize_key((string) call_user_func([$order, 'get_payment_method']));
        $payment_title = sanitize_text_field((string) call_user_func([$order, 'get_payment_method_title']));
        $allowed = $this->get_allowed_gateway_ids_for_recargas();

        call_user_func([$item, 'update_meta_data'], '_dc_transfer_status', 'blocked_gateway');
        call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_code', 'blocked_gateway');
        call_user_func([$item, 'update_meta_data'], '_dc_transfer_error_context', 'payment_method_policy');
        call_user_func([$item, 'update_meta_data'], '_dc_transfer_error', 'Despacho bloqueado por política de pasarelas: método de pago no permitido para recargas DingConnect.');
        call_user_func([$item, 'delete_meta_data'], '_dc_next_retry_at');
        call_user_func([$item, 'save']);

        $item_id = (int) call_user_func([$item, 'get_id']);
        wp_clear_scheduled_hook('dc_recargas_retry_transfer', [(int) $order->get_id(), $item_id]);

        $order->add_order_note(sprintf(
            'DingConnect: despacho bloqueado para item #%d por pasarela no permitida (id=%s, titulo=%s, permitidas=%s).',
            $item_id,
            $payment_method !== '' ? $payment_method : '-',
            $payment_title !== '' ? $payment_title : '-',
            !empty($allowed) ? implode(',', $allowed) : 'todas'
        ));
        $this->api->log_operational_event('gateway_blocked', [
            'status' => 'error',
            'order_id' => (int) $order->get_id(),
            'item_id' => $item_id,
            'account_number' => (string) $item->get_meta('_dc_account_number'),
            'sku_code' => (string) $item->get_meta('_dc_sku_code'),
            'send_value' => (float) $item->get_meta('_dc_send_value'),
            'currency' => (string) $item->get_meta('_dc_send_currency_iso'),
            'payment_method' => $payment_method,
            'raw_response' => [
                'payment_title' => $payment_title,
                'allowed_gateways' => $allowed,
            ],
        ]);
    }

    private function log_blocked_gateway_transfer($order, $item, $account_number, $sku_code, $send_value, $send_currency_iso) {
        if (!($order instanceof WC_Order) || !($item instanceof WC_Order_Item_Product)) {
            return;
        }

        $payment_method = sanitize_key((string) call_user_func([$order, 'get_payment_method']));
        $payment_title = sanitize_text_field((string) call_user_func([$order, 'get_payment_method_title']));
        $allowed = $this->get_allowed_gateway_ids_for_recargas();
        $distributor_ref = sprintf('WC-%d-ITEM-%d-BLOCKED-GATEWAY', (int) $order->get_id(), (int) $item->get_id());

        $response = new WP_Error(
            'blocked_gateway',
            'Despacho bloqueado por politica de pasarelas: metodo de pago no permitido para recargas DingConnect.',
            [
                'status' => 403,
                'ding_error_code' => 'blocked_gateway',
                'ding_error_context' => 'payment_method_policy',
                'order_id' => (int) $order->get_id(),
                'item_id' => (int) $item->get_id(),
                'payment_method' => $payment_method,
                'payment_title' => $payment_title,
                'allowed_gateways' => $allowed,
            ]
        );

        $this->api->log_transfer($account_number, $sku_code, $send_value, $send_currency_iso, $distributor_ref, $response);
    }

    private function log_diagnostic($message, $force = false) {
        if (!$force && (!defined('WP_DEBUG') || !WP_DEBUG)) {
            return;
        }

        error_log((string) $message);
    }
}
