<?php

if (!defined('ABSPATH')) {
    exit;
}

$canonical_entrypoint = __DIR__ . '/dingconnect-recargas.php';
if (file_exists($canonical_entrypoint)) {
    require_once $canonical_entrypoint;
}